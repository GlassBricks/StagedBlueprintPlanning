local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["4"] = 4,["5"] = 6,["6"] = 13,["7"] = 14,["8"] = 14,["9"] = 14,["11"] = 14,["13"] = 14,["14"] = 15,["15"] = 16,["17"] = 18,["18"] = 19,["19"] = 20,["20"] = 21,["22"] = 6,["23"] = 25});
local initCalled = false
local function init(a, b, c)
    local files = a or b or error("Files must be specified")
    local ____a_0
    if a then
        ____a_0 = b
    else
        ____a_0 = c
    end
    local config = ____a_0 or ({})
    if initCalled then
        error("Duplicate call to test init")
    end
    initCalled = true
    remote.add_interface("factorio-test-tests-available-for-" .. script.mod_name, {})
    if script.mod_name == settings.global["factorio-test-mod-to-test"].value then
        require("__factorio-test__._factorio-test")(files, config)
    end
end
local ____exports = init
return ____exports
