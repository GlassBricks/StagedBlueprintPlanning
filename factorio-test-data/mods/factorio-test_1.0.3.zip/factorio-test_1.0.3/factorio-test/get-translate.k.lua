-- workaround for TSTL treatment of hex escaped characters

return function(translate)
    return function(message)
        if type(message) == "string" then
            return message
        end
        local id, msg = translate(message)
        if id then
            return "\xEF\xB7\x94" .. id
        else
            return "<" .. tostring(msg) .. ">"
        end
    end
end
