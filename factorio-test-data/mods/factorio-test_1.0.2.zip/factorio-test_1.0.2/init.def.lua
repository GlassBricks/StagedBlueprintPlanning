---@param files string[]
---@param config FactorioTestConfig | nil
function init(files, config) end
