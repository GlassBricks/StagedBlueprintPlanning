local ____lualib = require("lualib_bundle")
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["11"] = 7,["12"] = 1,["13"] = 3,["14"] = 3,["15"] = 4,["16"] = 4,["17"] = 24,["18"] = 25,["19"] = 25,["20"] = 25,["21"] = 25,["22"] = 25,["24"] = 25,["26"] = 28,["27"] = 29,["28"] = 29,["29"] = 29,["30"] = 29,["32"] = 30,["33"] = 30,["35"] = 30,["36"] = 30,["38"] = 33,["39"] = 34,["40"] = 38,["41"] = 40,["42"] = 41,["43"] = 42,["44"] = 43,["46"] = 52,["47"] = 57,["48"] = 58,["49"] = 59,["52"] = 63,["53"] = 63,["54"] = 63,["55"] = 63,["56"] = 63,["57"] = 63,["58"] = 63,["59"] = 63,["60"] = 63,["61"] = 63,["64"] = 84,["65"] = 85,["67"] = 88,["68"] = 89,["69"] = 93,["70"] = 99,["71"] = 104,["72"] = 106,["73"] = 114,["74"] = 116,["75"] = 117,["76"] = 119,["77"] = 119,["78"] = 119,["79"] = 119,["80"] = 119,["81"] = 119,["82"] = 119,["83"] = 130,["84"] = 131,["85"] = 132,["86"] = 133,["88"] = 135,["89"] = 136,["90"] = 137,["92"] = 139,["95"] = 142,["96"] = 143,["97"] = 144,["98"] = 145,["99"] = 146,["100"] = 147,["103"] = 176,["104"] = 177,["105"] = 177,["106"] = 178,["108"] = 180,["109"] = 181,["110"] = 190,["111"] = 192,["112"] = 193,["114"] = 201,["115"] = 202,["116"] = 203,["119"] = 204,["120"] = 205,["122"] = 229,["123"] = 230,["124"] = 232,["125"] = 237,["126"] = 242,["127"] = 246,["128"] = 246,["129"] = 246,["130"] = 246,["131"] = 246,["132"] = 246,["133"] = 246,["135"] = 255,["136"] = 256,["139"] = 257,["140"] = 259,["141"] = 260,["142"] = 262,["143"] = 264,["144"] = 266,["145"] = 267,["146"] = 269,["147"] = 270,["149"] = 281,["150"] = 282,["151"] = 283,["152"] = 284,["154"] = 286,["156"] = 286,["158"] = 287,["159"] = 289,["160"] = 294,["161"] = 296,["162"] = 298,["163"] = 299,["164"] = 300,["165"] = 301,["166"] = 302,["168"] = 305,["169"] = 306,["172"] = 307,["173"] = 308,["174"] = 309,["175"] = 310,["176"] = 311,["179"] = 340,["180"] = 341,["183"] = 342,["184"] = 343,["185"] = 344,["187"] = 344,["190"] = 7,["191"] = 8,["192"] = 10,["193"] = 79,["194"] = 80,["195"] = 81,["196"] = 79,["197"] = 151,["198"] = 151,["199"] = 151,["200"] = 152,["201"] = 152,["202"] = 153,["203"] = 155,["204"] = 156,["205"] = 158,["206"] = 159,["207"] = 160,["208"] = 161,["209"] = 162,["210"] = 163,["212"] = 165,["213"] = 166,["215"] = 168,["216"] = 169,["218"] = 171,["220"] = 173,["221"] = 151,["222"] = 151,["223"] = 196,["224"] = 196,["225"] = 196,["226"] = 197,["227"] = 198,["228"] = 196,["229"] = 196,["230"] = 208,["231"] = 209,["232"] = 209,["233"] = 209,["234"] = 210,["235"] = 211,["236"] = 209,["237"] = 209,["238"] = 214,["239"] = 214,["240"] = 214,["241"] = 215,["242"] = 216,["245"] = 219,["246"] = 220,["247"] = 214,["248"] = 214,["249"] = 223,["250"] = 223,["251"] = 223,["252"] = 224,["253"] = 225,["254"] = 226,["255"] = 223,["256"] = 223,["257"] = 273,["258"] = 274,["259"] = 274,["260"] = 275,["261"] = 276,["262"] = 277,["264"] = 273,["265"] = 315,["266"] = 317,["267"] = 317,["268"] = 317,["269"] = 318,["270"] = 319,["272"] = 321,["273"] = 317,["274"] = 317,["275"] = 324,["276"] = 325,["277"] = 326,["279"] = 326,["281"] = 327,["282"] = 327,["283"] = 327,["284"] = 327,["285"] = 327,["286"] = 327,["287"] = 327,["288"] = 327,["289"] = 324,["290"] = 347,["291"] = 348,["292"] = 349,["294"] = 347,["295"] = 353,["296"] = 354,["297"] = 355,["298"] = 356,["299"] = 354,["300"] = 358,["301"] = 358,["302"] = 358,["303"] = 358});
local ____exports = {}
local modSelectGuiValid, getModDropdownItems, TitleBar, getTestMod, ModSelect, createModTextField, destroyModTextField, TestStageBar, updateConfigGui, createConfigGui, destroyConfigGui, refreshConfigGui, ModSelectGuiName, ModSelectWidth, thisModName, OnModSelectionChanged, OnModTextfieldChanged, ReloadMods, RunTests, DestroyConfigGui
local modGui = require("mod-gui")
local ____guiAction = require("control.guiAction")
local guiAction = ____guiAction.guiAction
local ____post_2Dload_2Daction = require("control.post-load-action")
local postLoadAction = ____post_2Dload_2Daction.postLoadAction
function modSelectGuiValid()
    local ____opt_2 = global.modSelectGui
    local ____opt_0 = ____opt_2 and ____opt_2.mainFrame
    local ____temp_4 = ____opt_0 and ____opt_0.valid
    if ____temp_4 == nil then
        ____temp_4 = false
    end
    return ____temp_4
end
function getModDropdownItems()
    local mods = __TS__ArrayFilter(
        __TS__ObjectKeys(script.active_mods),
        function(____, mod) return remote.interfaces["factorio-test-tests-available-for-" .. mod] end
    )
    local ____array_5 = __TS__SparseArrayNew(
        {"factorio-test.config-gui.none"},
        table.unpack(mods)
    )
    __TS__SparseArrayPush(____array_5, {"factorio-test.config-gui.other"})
    return {__TS__SparseArraySpread(____array_5)}
end
function TitleBar(parent, title)
    local titleBar = parent.add({type = "flow", direction = "horizontal"})
    titleBar.drag_target = parent
    local style = titleBar.style
    style.horizontal_spacing = 8
    style.height = 28
    titleBar.add({type = "label", caption = title, style = "frame_title", ignored_by_interaction = true})
    do
        local element = titleBar.add({type = "empty-widget", ignored_by_interaction = true, style = "draggable_space"})
        local style = element.style
        style.horizontally_stretchable = true
        style.height = 24
    end
    do
        titleBar.add({
            type = "sprite-button",
            style = "frame_action_button",
            sprite = "utility/close_white",
            hovered_sprite = "utility/close_black",
            clicked_sprite = "utility/close_black",
            tooltip = {"gui.close"},
            mouse_button_filter = {"left"},
            tags = {modName = thisModName, on_gui_click = DestroyConfigGui}
        })
    end
end
function getTestMod()
    return settings.global["factorio-test-mod-to-test"].value
end
function ModSelect(parent)
    local mainFlow = parent.add({type = "flow", direction = "horizontal"})
    mainFlow.add({type = "label", style = "caption_label", caption = {"factorio-test.config-gui.load-tests-for"}})
    local selectFlow = mainFlow.add({type = "flow", direction = "vertical"})
    local modSelectItems = getModDropdownItems()
    local modSelect = selectFlow.add({type = "drop-down", items = modSelectItems, tags = {modName = thisModName, on_gui_selection_state_changed = OnModSelectionChanged}})
    modSelect.style.minimal_width = ModSelectWidth
    local configGui = global.modSelectGui
    configGui.modSelect = modSelect
    configGui.refreshButton = mainFlow.add({
        type = "sprite-button",
        style = "tool_button",
        sprite = "utility/refresh",
        tooltip = {"factorio-test.config-gui.reload-mods"},
        tags = {modName = thisModName, on_gui_click = ReloadMods}
    })
    local modSelectedIndex
    local testMod = getTestMod()
    if testMod == "" then
        modSelectedIndex = 1
    else
        local foundIndex = __TS__ArrayIndexOf(modSelectItems, testMod)
        if foundIndex ~= -1 then
            modSelectedIndex = foundIndex + 1
        else
            modSelectedIndex = #modSelectItems
        end
    end
    modSelect.items = modSelectItems
    modSelect.selected_index = modSelectedIndex
    local modTextField
    if modSelectedIndex == #modSelectItems then
        modTextField = createModTextField()
        modTextField.text = testMod
    end
end
function createModTextField()
    local ____opt_7 = global.modSelectGui.modTextField
    if ____opt_7 and ____opt_7.valid then
        return global.modSelectGui.modTextField
    end
    local modSelect = global.modSelectGui.modSelect
    local textfield = modSelect.parent.add({type = "textfield", lose_focus_on_confirm = true, tags = {modName = thisModName, on_gui_text_changed = OnModTextfieldChanged}, index = 2})
    textfield.style.width = ModSelectWidth
    global.modSelectGui.modTextField = textfield
    return textfield
end
function destroyModTextField()
    local configGui = global.modSelectGui
    if not configGui.modTextField then
        return
    end
    configGui.modTextField.destroy()
    configGui.modTextField = nil
end
function TestStageBar(parent)
    local configGui = global.modSelectGui
    local mainFlow = parent.add({type = "flow", direction = "vertical"})
    local buttonFlow = mainFlow.add({type = "flow", direction = "horizontal"})
    buttonFlow.add({type = "empty-widget"}).style.horizontally_stretchable = true
    configGui.runButton = buttonFlow.add({
        type = "button",
        name = "runTests",
        style = "green_button",
        caption = {"factorio-test.config-gui.run-tests"},
        tags = {modName = thisModName, on_gui_click = RunTests}
    })
end
function updateConfigGui()
    if not modSelectGuiValid() then
        return
    end
    local configGui = global.modSelectGui
    local testModIsRegistered = remote.interfaces["factorio-test-tests-available-for-" .. getTestMod()] ~= nil
    local testModLoaded = remote.interfaces["factorio-test"] ~= nil and remote.call("factorio-test", "modName") == getTestMod()
    local stage = testModLoaded and remote.call("factorio-test", "getTestStage") or nil
    local running = stage == "Running" or stage == "ReloadingMods"
    configGui.modSelect.enabled = not running
    configGui.refreshButton.enabled = not running
    configGui.runButton.enabled = testModIsRegistered and not running
    configGui.runButton.tooltip = testModIsRegistered and "" or ({"factorio-test.config-gui.mod-not-registered"})
end
function createConfigGui(player)
    if game.is_multiplayer() then
        game.print("Cannot run tests in multiplayer")
        return nil
    end
    local ____opt_11 = player.gui.screen[ModSelectGuiName]
    if ____opt_11 ~= nil then
        ____opt_11.destroy()
    end
    global.modSelectGui = {player = player}
    local frame = player.gui.screen.add({type = "frame", name = ModSelectGuiName, direction = "vertical"})
    frame.auto_center = true
    global.modSelectGui.mainFrame = frame
    TitleBar(frame, {"factorio-test.config-gui.title"})
    ModSelect(frame)
    TestStageBar(frame)
    updateConfigGui()
    return frame
end
function destroyConfigGui()
    if not modSelectGuiValid() then
        return
    end
    local configGui = global.modSelectGui
    global.modSelectGui = nil
    local element = configGui.player.gui.screen[ModSelectGuiName]
    if element and element.valid then
        element.destroy()
    end
end
function refreshConfigGui()
    if not modSelectGuiValid() then
        return
    end
    local previousPlayer = global.modSelectGui.player
    destroyConfigGui()
    local ____opt_15 = createConfigGui(previousPlayer)
    if ____opt_15 ~= nil then
        ____opt_15.bring_to_front()
    end
end
ModSelectGuiName = "factorio-test:mod-select"
ModSelectWidth = 150
thisModName = script.mod_name
local function setTestMod(mod)
    settings.global["factorio-test-mod-to-test"] = {value = mod}
    updateConfigGui()
end
OnModSelectionChanged = guiAction(
    "OnModSelectionChanged",
    function()
        local ____global_modSelectGui_6 = global.modSelectGui
        local modSelect = ____global_modSelectGui_6.modSelect
        local modSelectItems = modSelect.items
        local selectedIndex = modSelect.selected_index
        local selected = modSelectItems[selectedIndex]
        local selectedMod
        local isOther = false
        if type(selected) == "string" then
            selectedMod = selected
        elseif selectedIndex == 1 then
            selectedMod = ""
        else
            isOther = true
            selectedMod = ""
        end
        if isOther then
            createModTextField()
        else
            destroyModTextField()
        end
        setTestMod(selectedMod)
    end
)
OnModTextfieldChanged = guiAction(
    "OnModTextfieldChanged",
    function(e)
        local element = e.element
        setTestMod(element.text)
    end
)
local refreshAfterLoad = postLoadAction("afterRefresh", refreshConfigGui)
ReloadMods = guiAction(
    "refresh",
    function()
        game.reload_mods()
        refreshAfterLoad()
    end
)
local callRunTests = postLoadAction(
    "runTests",
    function()
        if not remote.interfaces["factorio-test"] then
            game.print({"factorio-test.config-gui.mod-not-registered"})
            return
        end
        remote.call("factorio-test", "runTests")
        updateConfigGui()
    end
)
RunTests = guiAction(
    "startTests",
    function()
        game.reload_mods()
        game.auto_save("beforeTest")
        callRunTests()
    end
)
script.on_load(function()
    local ____opt_9 = remote.interfaces["factorio-test"]
    local remoteExits = ____opt_9 and ____opt_9.onTestStageChanged
    if remoteExits then
        local eventId = remote.call("factorio-test", "onTestStageChanged")
        script.on_event(eventId, updateConfigGui)
    end
end)
DestroyConfigGui = guiAction("destroyConfigGui", destroyConfigGui)
local CreateConfigGui = guiAction(
    "createConfigGui",
    function(e)
        if modSelectGuiValid() then
            destroyConfigGui()
        end
        createConfigGui(game.players[e.player_index])
    end
)
local function createModButton(player)
    local flow = modGui.get_button_flow(player)
    local ____opt_13 = flow[ModSelectGuiName]
    if ____opt_13 ~= nil then
        ____opt_13.destroy()
    end
    flow.add({
        type = "sprite-button",
        name = ModSelectGuiName,
        style = modGui.button_style,
        sprite = "factorio-test-test-tube-sprite",
        tooltip = {"factorio-test.tests"},
        tags = {modName = thisModName, on_gui_click = CreateConfigGui}
    })
end
local function createModButtonForAllPlayers()
    for ____, player in pairs(game.players) do
        createModButton(player)
    end
end
script.on_init(createModButtonForAllPlayers)
script.on_configuration_changed(function()
    createModButtonForAllPlayers()
    refreshConfigGui()
end)
script.on_event(
    {defines.events.on_player_created},
    function(e) return createModButton(game.players[e.player_index]) end
)
return ____exports
