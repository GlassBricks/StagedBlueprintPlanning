local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 3,["6"] = 3,["7"] = 3,["8"] = 4,["9"] = 5,["12"] = 7,["13"] = 9,["14"] = 10,["15"] = 11,["16"] = 12,["17"] = 13,["18"] = 14,["19"] = 9,["20"] = 17,["21"] = 18,["23"] = 21,["24"] = 22,["26"] = 25,["27"] = 26,["29"] = 29,["30"] = 3,["31"] = 3});
local ____exports = {}
script.on_event(
    defines.events.on_game_created_from_scenario,
    function()
        local shouldAutoStart = settings.startup["factorio-test-auto-start"].value
        if not shouldAutoStart then
            return
        end
        local modToTest = settings.global["factorio-test-mod-to-test"].value
        local function autoStartError(message)
            game.print(message)
            print("FACTORIO-TEST-MESSAGE-START")
            log(message)
            print("FACTORIO-TEST-MESSAGE-END")
            print("FACTORIO-TEST-RESULT:could not auto start")
        end
        if modToTest == "" then
            return autoStartError("Cannot auto-start tests: no mod selected.")
        end
        if not (script.active_mods[modToTest] ~= nil) then
            return autoStartError(("Cannot auto-start tests: mod " .. modToTest) .. " is not active.")
        end
        if remote.interfaces["factorio-test"] == nil then
            return autoStartError("Cannot auto-start tests: the selected mod is not registered with Factorio Test.")
        end
        remote.call("factorio-test", "runTests", modToTest)
    end
)
return ____exports
