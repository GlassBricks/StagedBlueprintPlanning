local ____lualib = require("lualib_bundle")
local __TS__ArrayIsArray = ____lualib.__TS__ArrayIsArray
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 4,["7"] = 5,["8"] = 6,["9"] = 7,["10"] = 8,["14"] = 10,["15"] = 5,["16"] = 13,["17"] = 14,["18"] = 15,["19"] = 15,["21"] = 16,["22"] = 17,["23"] = 18,["24"] = 17,["25"] = 14,["26"] = 22,["27"] = 22,["28"] = 22,["29"] = 23,["30"] = 24,["31"] = 25,["32"] = 26,["34"] = 26,["37"] = 22,["38"] = 22});
local ____exports = {}
local lsId = "factorio-test.fake-translation"
local function fireFakeTranslation(data)
    local ls = {lsId, data}
    for ____, player in ipairs(game.connected_players) do
        if player.request_translation(ls) then
            return
        end
    end
    error("No connected players found to raise fake translation event. Please report this to the mod author")
end
local loadEvents = {}
function ____exports.postLoadAction(name, func)
    if loadEvents[name] ~= nil then
        error("duplicate load event name " .. name)
    end
    loadEvents[name] = func
    return function()
        fireFakeTranslation(name)
    end
end
script.on_event(
    defines.events.on_string_translated,
    function(data)
        local ls = data.localised_string
        if __TS__ArrayIsArray(ls) and ls[1] == lsId then
            local action = ls[2]
            local ____opt_0 = loadEvents[action]
            if ____opt_0 ~= nil then
                ____opt_0()
            end
        end
    end
)
return ____exports
