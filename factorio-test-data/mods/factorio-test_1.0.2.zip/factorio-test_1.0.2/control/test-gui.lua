local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 1,["6"] = 1,["7"] = 4,["8"] = 6,["9"] = 7,["11"] = 4,["12"] = 11,["13"] = 11,["14"] = 11,["15"] = 12,["16"] = 13,["18"] = 15,["19"] = 15,["21"] = 15,["23"] = 11,["24"] = 11});
local ____exports = {}
local ____guiAction = require("control.guiAction")
local guiAction = ____guiAction.guiAction
local function getPlayer()
    for ____, player in pairs(game.players) do
        return player
    end
end
guiAction(
    "close-test-gui",
    function()
        if remote.interfaces["factorio-test"] then
            remote.call("factorio-test", "fireCustomEvent", "closeProgressGui")
        end
        local ____opt_2 = getPlayer()
        local ____opt_0 = ____opt_2 and ____opt_2.gui.screen["factorio-test-test-gui"]
        if ____opt_0 ~= nil then
            ____opt_0.destroy()
        end
    end
)
return ____exports
