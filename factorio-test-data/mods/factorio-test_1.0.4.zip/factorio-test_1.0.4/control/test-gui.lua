local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 1,["6"] = 1,["7"] = 5,["8"] = 7,["9"] = 8,["11"] = 5,["12"] = 12,["13"] = 12,["14"] = 12,["15"] = 13,["16"] = 14,["18"] = 16,["19"] = 16,["21"] = 16,["23"] = 12,["24"] = 12});
local ____exports = {}
local ____guiAction = require("control.guiAction")
local guiAction = ____guiAction.guiAction
local function getPlayer()
    for ____, player in pairs(game.players) do
        return player
    end
end
guiAction(
    "close-test-gui",
    function()
        if remote.interfaces["factorio-test"] then
            remote.call("factorio-test", "fireCustomEvent", "closeProgressGui")
        end
        local ____opt_2 = getPlayer()
        local ____opt_0 = ____opt_2 and ____opt_2.gui.screen["factorio-test-test-gui"]
        if ____opt_0 ~= nil then
            ____opt_0.destroy()
        end
    end
)
return ____exports
