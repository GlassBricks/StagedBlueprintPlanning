local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 4,["6"] = 4,["7"] = 4,["8"] = 5,["9"] = 6,["12"] = 8,["13"] = 10,["14"] = 11,["15"] = 12,["16"] = 13,["17"] = 14,["18"] = 15,["19"] = 10,["20"] = 18,["21"] = 19,["23"] = 22,["24"] = 23,["26"] = 26,["27"] = 27,["29"] = 30,["30"] = 4,["31"] = 4});
local ____exports = {}
script.on_event(
    defines.events.on_game_created_from_scenario,
    function()
        local shouldAutoStart = settings.startup["factorio-test-auto-start"].value
        if not shouldAutoStart then
            return
        end
        local modToTest = settings.global["factorio-test-mod-to-test"].value
        local function autoStartError(message)
            game.print(message)
            print("FACTORIO-TEST-MESSAGE-START")
            log(message)
            print("FACTORIO-TEST-MESSAGE-END")
            print("FACTORIO-TEST-RESULT:could not auto start")
        end
        if modToTest == "" then
            return autoStartError("Cannot auto-start tests: no mod selected.")
        end
        if not (script.active_mods[modToTest] ~= nil) then
            return autoStartError(("Cannot auto-start tests: mod " .. modToTest) .. " is not active.")
        end
        if remote.interfaces["factorio-test"] == nil then
            return autoStartError("Cannot auto-start tests: the selected mod is not registered with Factorio Test.")
        end
        remote.call("factorio-test", "runTests", modToTest)
    end
)
return ____exports
