local ____lualib = require("lualib_bundle")
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["11"] = 19,["12"] = 1,["13"] = 3,["14"] = 3,["15"] = 4,["16"] = 4,["17"] = 36,["18"] = 37,["19"] = 37,["20"] = 37,["21"] = 37,["22"] = 37,["24"] = 37,["26"] = 40,["27"] = 41,["28"] = 41,["29"] = 41,["30"] = 41,["32"] = 42,["33"] = 42,["35"] = 42,["36"] = 42,["38"] = 45,["39"] = 46,["40"] = 50,["41"] = 52,["42"] = 53,["43"] = 54,["44"] = 55,["46"] = 64,["47"] = 69,["48"] = 70,["49"] = 71,["52"] = 75,["53"] = 75,["54"] = 75,["55"] = 75,["56"] = 75,["57"] = 75,["58"] = 75,["59"] = 75,["60"] = 75,["61"] = 75,["64"] = 96,["65"] = 97,["67"] = 100,["68"] = 101,["69"] = 105,["70"] = 111,["71"] = 116,["72"] = 118,["73"] = 126,["74"] = 128,["75"] = 129,["76"] = 131,["77"] = 131,["78"] = 131,["79"] = 131,["80"] = 131,["81"] = 131,["82"] = 131,["83"] = 142,["84"] = 143,["85"] = 144,["86"] = 145,["88"] = 147,["89"] = 148,["90"] = 149,["92"] = 151,["95"] = 154,["96"] = 155,["97"] = 156,["98"] = 157,["99"] = 158,["100"] = 159,["103"] = 188,["104"] = 189,["105"] = 189,["106"] = 190,["108"] = 192,["109"] = 193,["110"] = 202,["111"] = 204,["112"] = 205,["114"] = 213,["115"] = 214,["116"] = 215,["119"] = 216,["120"] = 217,["122"] = 241,["123"] = 242,["124"] = 244,["125"] = 249,["126"] = 254,["127"] = 258,["128"] = 258,["129"] = 258,["130"] = 258,["131"] = 258,["132"] = 258,["133"] = 258,["135"] = 267,["136"] = 268,["139"] = 269,["140"] = 271,["141"] = 272,["142"] = 274,["143"] = 276,["144"] = 278,["145"] = 279,["146"] = 281,["147"] = 282,["149"] = 293,["150"] = 294,["151"] = 295,["152"] = 296,["154"] = 298,["156"] = 298,["158"] = 299,["159"] = 301,["160"] = 306,["161"] = 308,["162"] = 310,["163"] = 311,["164"] = 312,["165"] = 313,["166"] = 314,["168"] = 317,["169"] = 318,["172"] = 319,["173"] = 320,["174"] = 321,["175"] = 322,["176"] = 323,["179"] = 352,["180"] = 353,["183"] = 354,["184"] = 355,["185"] = 356,["187"] = 356,["190"] = 19,["191"] = 20,["192"] = 22,["193"] = 91,["194"] = 92,["195"] = 93,["196"] = 91,["197"] = 163,["198"] = 163,["199"] = 163,["200"] = 164,["201"] = 164,["202"] = 165,["203"] = 167,["204"] = 168,["205"] = 170,["206"] = 171,["207"] = 172,["208"] = 173,["209"] = 174,["210"] = 175,["212"] = 177,["213"] = 178,["215"] = 180,["216"] = 181,["218"] = 183,["220"] = 185,["221"] = 163,["222"] = 163,["223"] = 208,["224"] = 208,["225"] = 208,["226"] = 209,["227"] = 210,["228"] = 208,["229"] = 208,["230"] = 220,["231"] = 221,["232"] = 221,["233"] = 221,["234"] = 222,["235"] = 223,["236"] = 221,["237"] = 221,["238"] = 226,["239"] = 226,["240"] = 226,["241"] = 227,["242"] = 228,["245"] = 231,["246"] = 232,["247"] = 226,["248"] = 226,["249"] = 235,["250"] = 235,["251"] = 235,["252"] = 236,["253"] = 237,["254"] = 238,["255"] = 235,["256"] = 235,["257"] = 285,["258"] = 286,["259"] = 286,["260"] = 287,["261"] = 288,["262"] = 289,["264"] = 285,["265"] = 327,["266"] = 329,["267"] = 329,["268"] = 329,["269"] = 330,["270"] = 331,["272"] = 333,["273"] = 329,["274"] = 329,["275"] = 336,["276"] = 337,["277"] = 338,["279"] = 338,["281"] = 339,["282"] = 339,["283"] = 339,["284"] = 339,["285"] = 339,["286"] = 339,["287"] = 339,["288"] = 339,["289"] = 336,["290"] = 359,["291"] = 360,["292"] = 361,["294"] = 359,["295"] = 365,["296"] = 366,["297"] = 367,["298"] = 368,["299"] = 366,["300"] = 370,["301"] = 370,["302"] = 370,["303"] = 370});
local ____exports = {}
local modSelectGuiValid, getModDropdownItems, TitleBar, getTestMod, ModSelect, createModTextField, destroyModTextField, TestStageBar, updateConfigGui, createConfigGui, destroyConfigGui, refreshConfigGui, ModSelectGuiName, ModSelectWidth, thisModName, OnModSelectionChanged, OnModTextfieldChanged, ReloadMods, RunTests, DestroyConfigGui
local modGui = require("mod-gui")
local ____guiAction = require("control.guiAction")
local guiAction = ____guiAction.guiAction
local ____post_2Dload_2Daction = require("control.post-load-action")
local postLoadAction = ____post_2Dload_2Daction.postLoadAction
function modSelectGuiValid()
    local ____opt_2 = storage.modSelectGui
    local ____opt_0 = ____opt_2 and ____opt_2.mainFrame
    local ____temp_4 = ____opt_0 and ____opt_0.valid
    if ____temp_4 == nil then
        ____temp_4 = false
    end
    return ____temp_4
end
function getModDropdownItems()
    local mods = __TS__ArrayFilter(
        __TS__ObjectKeys(script.active_mods),
        function(____, mod) return remote.interfaces["factorio-test-tests-available-for-" .. mod] end
    )
    local ____array_5 = __TS__SparseArrayNew(
        {"factorio-test.config-gui.none"},
        table.unpack(mods)
    )
    __TS__SparseArrayPush(____array_5, {"factorio-test.config-gui.other"})
    return {__TS__SparseArraySpread(____array_5)}
end
function TitleBar(parent, title)
    local titleBar = parent.add({type = "flow", direction = "horizontal"})
    titleBar.drag_target = parent
    local style = titleBar.style
    style.horizontal_spacing = 8
    style.height = 28
    titleBar.add({type = "label", caption = title, style = "frame_title", ignored_by_interaction = true})
    do
        local element = titleBar.add({type = "empty-widget", ignored_by_interaction = true, style = "draggable_space"})
        local style = element.style
        style.horizontally_stretchable = true
        style.height = 24
    end
    do
        titleBar.add({
            type = "sprite-button",
            style = "frame_action_button",
            sprite = "utility/close",
            hovered_sprite = "utility/close_black",
            clicked_sprite = "utility/close_black",
            tooltip = {"gui.close"},
            mouse_button_filter = {"left"},
            tags = {modName = thisModName, on_gui_click = DestroyConfigGui}
        })
    end
end
function getTestMod()
    return settings.global["factorio-test-mod-to-test"].value
end
function ModSelect(parent)
    local mainFlow = parent.add({type = "flow", direction = "horizontal"})
    mainFlow.add({type = "label", style = "caption_label", caption = {"factorio-test.config-gui.load-tests-for"}})
    local selectFlow = mainFlow.add({type = "flow", direction = "vertical"})
    local modSelectItems = getModDropdownItems()
    local modSelect = selectFlow.add({type = "drop-down", items = modSelectItems, tags = {modName = thisModName, on_gui_selection_state_changed = OnModSelectionChanged}})
    modSelect.style.minimal_width = ModSelectWidth
    local configGui = storage.modSelectGui
    configGui.modSelect = modSelect
    configGui.refreshButton = mainFlow.add({
        type = "sprite-button",
        style = "tool_button",
        sprite = "utility/refresh",
        tooltip = {"factorio-test.config-gui.reload-mods"},
        tags = {modName = thisModName, on_gui_click = ReloadMods}
    })
    local modSelectedIndex
    local testMod = getTestMod()
    if testMod == "" then
        modSelectedIndex = 1
    else
        local foundIndex = __TS__ArrayIndexOf(modSelectItems, testMod)
        if foundIndex ~= -1 then
            modSelectedIndex = foundIndex + 1
        else
            modSelectedIndex = #modSelectItems
        end
    end
    modSelect.items = modSelectItems
    modSelect.selected_index = modSelectedIndex
    local modTextField
    if modSelectedIndex == #modSelectItems then
        modTextField = createModTextField()
        modTextField.text = testMod
    end
end
function createModTextField()
    local ____opt_7 = storage.modSelectGui.modTextField
    if ____opt_7 and ____opt_7.valid then
        return storage.modSelectGui.modTextField
    end
    local modSelect = storage.modSelectGui.modSelect
    local textfield = modSelect.parent.add({type = "textfield", lose_focus_on_confirm = true, tags = {modName = thisModName, on_gui_text_changed = OnModTextfieldChanged}, index = 2})
    textfield.style.width = ModSelectWidth
    storage.modSelectGui.modTextField = textfield
    return textfield
end
function destroyModTextField()
    local configGui = storage.modSelectGui
    if not configGui.modTextField then
        return
    end
    configGui.modTextField.destroy()
    configGui.modTextField = nil
end
function TestStageBar(parent)
    local configGui = storage.modSelectGui
    local mainFlow = parent.add({type = "flow", direction = "vertical"})
    local buttonFlow = mainFlow.add({type = "flow", direction = "horizontal"})
    buttonFlow.add({type = "empty-widget"}).style.horizontally_stretchable = true
    configGui.runButton = buttonFlow.add({
        type = "button",
        name = "runTests",
        style = "green_button",
        caption = {"factorio-test.config-gui.run-tests"},
        tags = {modName = thisModName, on_gui_click = RunTests}
    })
end
function updateConfigGui()
    if not modSelectGuiValid() then
        return
    end
    local configGui = storage.modSelectGui
    local testModIsRegistered = remote.interfaces["factorio-test-tests-available-for-" .. getTestMod()] ~= nil
    local testModLoaded = remote.interfaces["factorio-test"] ~= nil and remote.call("factorio-test", "modName") == getTestMod()
    local stage = testModLoaded and remote.call("factorio-test", "getTestStage") or nil
    local running = stage == "Running" or stage == "ReloadingMods"
    configGui.modSelect.enabled = not running
    configGui.refreshButton.enabled = not running
    configGui.runButton.enabled = testModIsRegistered and not running
    configGui.runButton.tooltip = testModIsRegistered and "" or ({"factorio-test.config-gui.mod-not-registered"})
end
function createConfigGui(player)
    if game.is_multiplayer() then
        game.print("Cannot run tests in multiplayer")
        return nil
    end
    local ____opt_11 = player.gui.screen[ModSelectGuiName]
    if ____opt_11 ~= nil then
        ____opt_11.destroy()
    end
    storage.modSelectGui = {player = player}
    local frame = player.gui.screen.add({type = "frame", name = ModSelectGuiName, direction = "vertical"})
    frame.auto_center = true
    storage.modSelectGui.mainFrame = frame
    TitleBar(frame, {"factorio-test.config-gui.title"})
    ModSelect(frame)
    TestStageBar(frame)
    updateConfigGui()
    return frame
end
function destroyConfigGui()
    if not modSelectGuiValid() then
        return
    end
    local configGui = storage.modSelectGui
    storage.modSelectGui = nil
    local element = configGui.player.gui.screen[ModSelectGuiName]
    if element and element.valid then
        element.destroy()
    end
end
function refreshConfigGui()
    if not modSelectGuiValid() then
        return
    end
    local previousPlayer = storage.modSelectGui.player
    destroyConfigGui()
    local ____opt_15 = createConfigGui(previousPlayer)
    if ____opt_15 ~= nil then
        ____opt_15.bring_to_front()
    end
end
ModSelectGuiName = "factorio-test:mod-select"
ModSelectWidth = 150
thisModName = script.mod_name
local function setTestMod(mod)
    settings.global["factorio-test-mod-to-test"] = {value = mod}
    updateConfigGui()
end
OnModSelectionChanged = guiAction(
    "OnModSelectionChanged",
    function()
        local ____storage_modSelectGui_6 = storage.modSelectGui
        local modSelect = ____storage_modSelectGui_6.modSelect
        local modSelectItems = modSelect.items
        local selectedIndex = modSelect.selected_index
        local selected = modSelectItems[selectedIndex]
        local selectedMod
        local isOther = false
        if type(selected) == "string" then
            selectedMod = selected
        elseif selectedIndex == 1 then
            selectedMod = ""
        else
            isOther = true
            selectedMod = ""
        end
        if isOther then
            createModTextField()
        else
            destroyModTextField()
        end
        setTestMod(selectedMod)
    end
)
OnModTextfieldChanged = guiAction(
    "OnModTextfieldChanged",
    function(e)
        local element = e.element
        setTestMod(element.text)
    end
)
local refreshAfterLoad = postLoadAction("afterRefresh", refreshConfigGui)
ReloadMods = guiAction(
    "refresh",
    function()
        game.reload_mods()
        refreshAfterLoad()
    end
)
local callRunTests = postLoadAction(
    "runTests",
    function()
        if not remote.interfaces["factorio-test"] then
            game.print({"factorio-test.config-gui.mod-not-registered"})
            return
        end
        remote.call("factorio-test", "runTests")
        updateConfigGui()
    end
)
RunTests = guiAction(
    "start-tests",
    function()
        game.reload_mods()
        game.auto_save("beforeTest")
        callRunTests()
    end
)
script.on_load(function()
    local ____opt_9 = remote.interfaces["factorio-test"]
    local remoteExits = ____opt_9 and ____opt_9.onTestStageChanged
    if remoteExits then
        local eventId = remote.call("factorio-test", "onTestStageChanged")
        script.on_event(eventId, updateConfigGui)
    end
end)
DestroyConfigGui = guiAction("destroyConfigGui", destroyConfigGui)
local CreateConfigGui = guiAction(
    "createConfigGui",
    function(e)
        if modSelectGuiValid() then
            destroyConfigGui()
        end
        createConfigGui(game.players[e.player_index])
    end
)
local function createModButton(player)
    local flow = modGui.get_button_flow(player)
    local ____opt_13 = flow[ModSelectGuiName]
    if ____opt_13 ~= nil then
        ____opt_13.destroy()
    end
    flow.add({
        type = "sprite-button",
        name = ModSelectGuiName,
        style = modGui.button_style,
        sprite = "factorio-test-test-tube-sprite",
        tooltip = {"factorio-test.tests"},
        tags = {modName = thisModName, on_gui_click = CreateConfigGui}
    })
end
local function createModButtonForAllPlayers()
    for ____, player in pairs(game.players) do
        createModButton(player)
    end
end
script.on_init(createModButtonForAllPlayers)
script.on_configuration_changed(function()
    createModButtonForAllPlayers()
    refreshConfigGui()
end)
script.on_event(
    {defines.events.on_player_created},
    function(e) return createModButton(game.players[e.player_index]) end
)
return ____exports
