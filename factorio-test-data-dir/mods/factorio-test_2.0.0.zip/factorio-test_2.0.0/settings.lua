local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 6,["6"] = 7,["7"] = 7,["8"] = 7,["9"] = 7,["10"] = 7,["11"] = 7,["12"] = 6,["13"] = 15,["14"] = 15,["15"] = 15,["16"] = 15,["17"] = 15,["18"] = 6});
local ____exports = {}
data:extend({{
    type = "string-setting",
    setting_type = "runtime-global",
    name = "factorio-test-mod-to-test",
    default_value = "",
    allow_blank = true,
    order = "a"
}, {
    type = "bool-setting",
    setting_type = "startup",
    name = "factorio-test-auto-start",
    default_value = false,
    order = "b"
}})
return ____exports
