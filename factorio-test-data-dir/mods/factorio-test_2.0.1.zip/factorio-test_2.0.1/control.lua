local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 1,["6"] = 6,["7"] = 9});
local ____exports = {}
require("control.index")
if settings.startup["factorio-test-auto-start"].value == true and settings.global["factorio-test-mod-to-test"].value == script.mod_name then
    require("__factorio-test__/init")({"test.meta.test", "test.reload.test"})
end
return ____exports
