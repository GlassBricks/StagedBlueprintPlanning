-- load basic machers
require('__factorio-test__.luassert.matchers.core')
require('__factorio-test__.luassert.matchers.composite')
