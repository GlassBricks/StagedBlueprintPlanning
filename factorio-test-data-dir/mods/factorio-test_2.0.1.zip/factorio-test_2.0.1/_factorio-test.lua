--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]

local ____modules = {}
local ____moduleCache = {}
local ____originalRequire = require
local function require(file, ...)
    if ____moduleCache[file] then
        return ____moduleCache[file].value
    end
    if ____modules[file] then
        local module = ____modules[file]
        local value = nil
        if (select("#", ...) > 0) then value = module(...) else value = module(file) end
        ____moduleCache[file] = { value = value }
        return value
    else
        if ____originalRequire then
            return ____originalRequire(file)
        else
            error("module '" .. file .. "' not found")
        end
    end
end
____modules = {
["lualib_bundle"] = function(...) 
local __TS__StringSplit
do
    local sub = string.sub
    local find = string.find
    function __TS__StringSplit(source, separator, limit)
        if limit == nil then
            limit = 4294967295
        end
        if limit == 0 then
            return {}
        end
        local result = {}
        local resultIndex = 1
        if separator == nil or separator == "" then
            for i = 1, #source do
                result[resultIndex] = sub(source, i, i)
                resultIndex = resultIndex + 1
            end
        else
            local currentPos = 1
            while resultIndex <= limit do
                local startPos, endPos = find(source, separator, currentPos, true)
                if not startPos then
                    break
                end
                result[resultIndex] = sub(source, currentPos, startPos - 1)
                resultIndex = resultIndex + 1
                currentPos = endPos + 1
            end
            if resultIndex <= limit then
                result[resultIndex] = sub(source, currentPos)
            end
        end
        return result
    end
end

local function __TS__StringEndsWith(self, searchString, endPosition)
    if endPosition == nil or endPosition > #self then
        endPosition = #self
    end
    return string.sub(self, endPosition - #searchString + 1, endPosition) == searchString
end

local function __TS__ArrayJoin(self, separator)
    if separator == nil then
        separator = ","
    end
    local parts = {}
    for i = 1, #self do
        parts[i] = tostring(self[i])
    end
    return table.concat(parts, separator)
end

local function __TS__StringStartsWith(self, searchString, position)
    if position == nil or position < 0 then
        position = 0
    end
    return string.sub(self, position + 1, #searchString + position) == searchString
end

local function __TS__ObjectAssign(target, ...)
    local sources = {...}
    for i = 1, #sources do
        local source = sources[i]
        for key in pairs(source) do
            target[key] = source[key]
        end
    end
    return target
end

local function __TS__ArrayMap(self, callbackfn, thisArg)
    local result = {}
    for i = 1, #self do
        result[i] = callbackfn(thisArg, self[i], i - 1, self)
    end
    return result
end

local function __TS__ArrayEvery(self, callbackfn, thisArg)
    for i = 1, #self do
        if not callbackfn(thisArg, self[i], i - 1, self) then
            return false
        end
    end
    return true
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ArrayIndexOf(self, searchElement, fromIndex)
    if fromIndex == nil then
        fromIndex = 0
    end
    local len = #self
    if len == 0 then
        return -1
    end
    if fromIndex >= len then
        return -1
    end
    if fromIndex < 0 then
        fromIndex = len + fromIndex
        if fromIndex < 0 then
            fromIndex = 0
        end
    end
    for i = fromIndex + 1, len do
        if self[i] == searchElement then
            return i - 1
        end
    end
    return -1
end

local function __TS__ArrayFilter(self, callbackfn, thisArg)
    local result = {}
    local len = 0
    for i = 1, #self do
        if callbackfn(thisArg, self[i], i - 1, self) then
            len = len + 1
            result[len] = self[i]
        end
    end
    return result
end

local function __TS__ArrayPushArray(self, items)
    local len = #self
    for i = 1, #items do
        len = len + 1
        self[len] = items[i]
    end
    return len
end

local function __TS__ObjectKeys(obj)
    local result = {}
    local len = 0
    for key in pairs(obj) do
        len = len + 1
        result[len] = key
    end
    return result
end

local function __TS__ArraySome(self, callbackfn, thisArg)
    for i = 1, #self do
        if callbackfn(thisArg, self[i], i - 1, self) then
            return true
        end
    end
    return false
end

local function __TS__ArrayIsArray(value)
    return type(value) == "table" and (value[1] ~= nil or next(value) == nil)
end

local function __TS__ArrayForEach(self, callbackFn, thisArg)
    for i = 1, #self do
        callbackFn(thisArg, self[i], i - 1, self)
    end
end

return {
  __TS__StringSplit = __TS__StringSplit,
  __TS__StringEndsWith = __TS__StringEndsWith,
  __TS__ArrayJoin = __TS__ArrayJoin,
  __TS__StringStartsWith = __TS__StringStartsWith,
  __TS__ObjectAssign = __TS__ObjectAssign,
  __TS__ArrayMap = __TS__ArrayMap,
  __TS__ArrayEvery = __TS__ArrayEvery,
  __TS__New = __TS__New,
  __TS__Class = __TS__Class,
  __TS__ArrayIndexOf = __TS__ArrayIndexOf,
  __TS__ArrayFilter = __TS__ArrayFilter,
  __TS__ArrayPushArray = __TS__ArrayPushArray,
  __TS__ObjectKeys = __TS__ObjectKeys,
  __TS__ArraySome = __TS__ArraySome,
  __TS__ArrayIsArray = __TS__ArrayIsArray,
  __TS__ArrayForEach = __TS__ArrayForEach
}
 end,
["_util"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local ____exports = {}
local getErrorWithStacktrace
function getErrorWithStacktrace(____error)
    local stacktrace = debug.traceback(
        tostring(____error),
        3
    )
    local lines = __TS__StringSplit(stacktrace, "\n")
    do
        local i = 1
        local l = #lines
        while i <= l do
            if __TS__StringEndsWith(lines[i], ": in function '__factorio_test__pcallWithStacktrace'") then
                if lines[i - 3 + 1] == "\t[C]: in function 'rawxpcall'" then
                    i = i - 1
                end
                return table.concat(lines, "\n", 1, i - 2)
            end
            i = i + 1
        end
    end
    return stacktrace
end
function ____exports.__factorio_test__pcallWithStacktrace(fn, ...)
    local success, result = xpcall(fn, getErrorWithStacktrace, ...)
    return success, result
end
____exports.debugAdapterEnabled = script.active_mods.debugadapter ~= nil
function ____exports.assertNever(value)
    return error(("value " .. tostring(value)) .. " should be never")
end
return ____exports
 end,
["results"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
function ____exports.createEmptyRunResults()
    return {
        failed = 0,
        passed = 0,
        ran = 0,
        skipped = 0,
        todo = 0,
        describeBlockErrors = 0
    }
end
____exports.resultCollector = function(event, state)
    if event.type == "testRunStarted" then
        state.results = ____exports.createEmptyRunResults()
        return
    end
    local results = state.results
    repeat
        local ____switch5 = event.type
        local ____cond5 = ____switch5 == "testPassed"
        if ____cond5 then
            do
                results.ran = results.ran + 1
                results.passed = results.passed + 1
                break
            end
        end
        ____cond5 = ____cond5 or ____switch5 == "testFailed"
        if ____cond5 then
            do
                results.ran = results.ran + 1
                results.failed = results.failed + 1
                break
            end
        end
        ____cond5 = ____cond5 or ____switch5 == "testSkipped"
        if ____cond5 then
            do
                results.skipped = results.skipped + 1
                break
            end
        end
        ____cond5 = ____cond5 or ____switch5 == "testTodo"
        if ____cond5 then
            do
                results.todo = results.todo + 1
                break
            end
        end
        ____cond5 = ____cond5 or ____switch5 == "describeBlockFailed"
        if ____cond5 then
            do
                results.describeBlockErrors = results.describeBlockErrors + #event.block.errors
                break
            end
        end
        ____cond5 = ____cond5 or ____switch5 == "testRunFinished"
        if ____cond5 then
            if results.failed ~= 0 or results.describeBlockErrors ~= 0 then
                results.status = "failed"
            elseif results.todo ~= 0 then
                results.status = "todo"
            else
                results.status = "passed"
            end
            break
        end
    until true
end
return ____exports
 end,
["tests"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local _____util = require("_util")
local assertNever = _____util.assertNever
function ____exports.formatSource(source)
    if not source.file then
        return "<unknown source>"
    end
    return (source.file .. ":") .. tostring(source.line or 1)
end
local function tryUseSourcemap(rawFile, line)
    if not rawFile or not line or not __TS__sourcemap then
        return nil
    end
    local fileName = string.match(rawFile, "@?(%S+)%.lua")
    if not fileName then
        return nil
    end
    local fileSourceMap = __TS__sourcemap[fileName .. ".lua"]
    if not fileSourceMap then
        return nil
    end
    local data = fileSourceMap[tostring(line)]
    if not data then
        return nil
    end
    return type(data) == "number" and ({file = fileName .. ".ts", line = data}) or data
end
function ____exports.createSource(file, line)
    return tryUseSourcemap(file, line) or ({file = file, line = line})
end
function ____exports.addTest(parent, name, source, func, declaredMode, tags)
    local test = {
        type = "test",
        name = name,
        path = (parent.path .. " > ") .. name,
        tags = tags,
        parent = parent,
        source = source,
        indexInParent = #parent.children,
        parts = {{func = func, source = source}},
        errors = {},
        declaredMode = declaredMode,
        mode = declaredMode,
        ticksBefore = parent.ticksBetweenTests
    }
    local ____parent_children_0 = parent.children
    ____parent_children_0[#____parent_children_0 + 1] = test
    return test
end
function ____exports.addDescribeBlock(parent, name, source, declaredMode, tags)
    local block = {
        type = "describeBlock",
        name = name,
        path = parent.path ~= "" and (parent.path .. " > ") .. name or name,
        tags = tags,
        parent = parent,
        indexInParent = parent and #parent.children or -1,
        source = source,
        hooks = {},
        children = {},
        declaredMode = declaredMode,
        ticksBetweenTests = parent.ticksBetweenTests,
        errors = {}
    }
    local ____parent_children_3 = parent.children
    ____parent_children_3[#____parent_children_3 + 1] = block
    return block
end
function ____exports.createRootDescribeBlock(config)
    return {
        type = "describeBlock",
        name = "",
        path = "",
        tags = {},
        source = {},
        parent = nil,
        children = {},
        indexInParent = -1,
        hooks = {},
        declaredMode = nil,
        mode = nil,
        ticksBetweenTests = config.default_ticks_between_tests,
        errors = {}
    }
end
local function testMatchesTagList(test, config)
    if config.tag_whitelist then
        for ____, tag in ipairs(config.tag_whitelist) do
            if not (test.tags[tag] ~= nil) then
                return false
            end
        end
    end
    if config.tag_blacklist then
        for ____, tag in ipairs(config.tag_blacklist) do
            if test.tags[tag] ~= nil then
                return false
            end
        end
    end
    return true
end
function ____exports.isSkippedTest(test, state)
    return test.mode == "skip" or test.mode == "todo" or state.hasFocusedTests and test.mode ~= "only" or state.config.test_pattern ~= nil and not (string.match(test.path, state.config.test_pattern)) or not testMatchesTagList(test, state.config)
end
function ____exports.countActiveTests(block, state)
    if block.mode == "skip" then
        return 0
    end
    local result = 0
    for ____, child in ipairs(block.children) do
        if child.type == "describeBlock" then
            result = result + ____exports.countActiveTests(child, state)
        elseif child.type == "test" then
            if not ____exports.isSkippedTest(child, state) then
                result = result + 1
            end
        else
            assertNever(child)
        end
    end
    return result
end
return ____exports
 end,
["state"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____results = require("results")
local createEmptyRunResults = ____results.createEmptyRunResults
local ____test_2Devents = require("test-events")
local _raiseTestEvent = ____test_2Devents._raiseTestEvent
local ____tests = require("tests")
local createRootDescribeBlock = ____tests.createRootDescribeBlock
local TheTestState
function ____exports.getTestState()
    return TheTestState or error("Tests are not configured to be run")
end
function ____exports._setTestState(state)
    TheTestState = state
end
function ____exports.getGlobalTestStage()
    return storage.__factorio_testTestStage or "NotRun"
end
local onTestStageChanged = script.generate_event_name()
____exports.onTestStageChanged = onTestStageChanged
local function setGlobalTestStage(stage)
    storage.__factorio_testTestStage = stage
    script.raise_event(onTestStageChanged, {stage = stage})
end
function ____exports.resetTestState(config)
    local rootBlock = createRootDescribeBlock(config)
    ____exports._setTestState({
        config = config,
        rootBlock = rootBlock,
        currentBlock = rootBlock,
        hasFocusedTests = false,
        results = createEmptyRunResults(),
        getTestStage = ____exports.getGlobalTestStage,
        setTestStage = setGlobalTestStage,
        raiseTestEvent = function(self, event)
            _raiseTestEvent(self, event)
        end
    })
end
function ____exports.cleanupTestState()
    local state = ____exports.getTestState()
    state.config = nil
    state.rootBlock = nil
    state.currentBlock = nil
    state.currentTestRun = nil
end
function ____exports.setToLoadErrorState(state, ____error)
    state.setTestStage("LoadError")
    state.rootBlock = createRootDescribeBlock(state.config)
    state.currentBlock = nil
    state.currentTestRun = nil
    state.rootBlock.errors = {____error}
    game.speed = 1
end
function ____exports.getCurrentBlock()
    return ____exports.getTestState().currentBlock or error("Tests and hooks cannot be added/configured at this time")
end
return ____exports
 end,
["test-events"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local testListeners = {}
function ____exports.clearTestListeners()
    testListeners = {}
end
function ____exports.addTestListener(self, listener)
    testListeners[#testListeners + 1] = listener
end
function ____exports._raiseTestEvent(state, event)
    for ____, handler in ipairs(testListeners) do
        handler(event, state)
    end
end
return ____exports
 end,
["output"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayJoin = ____lualib.__TS__ArrayJoin
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local ____exports = {}
local _____util = require("_util")
local debugAdapterEnabled = _____util.debugAdapterEnabled
____exports.Colors = {
    [1] = {1, 1, 1},
    [2] = {71, 221, 37},
    [3] = {252, 237, 50},
    [4] = {230, 60, 60},
    [5] = {177, 156, 220}
}
local ColorFormat = {}
for code, color in pairs(____exports.Colors) do
    ColorFormat[code] = ("[color=" .. __TS__ArrayJoin(color)) .. "]"
end
local function red(text)
    return {text = text, color = 4}
end
local function yellow(text)
    return {text = text, color = 3}
end
local function green(text)
    return {text = text, color = 2}
end
local function purple(text)
    return {text = text, color = 5}
end
local function formatError(text)
    local withSpaces = (string.gsub(text, "\t", "    "))
    local withIndent = (string.gsub(withSpaces, "\n", "\n    "))
    return {richText = "    " .. withIndent, plainText = text, firstColor = 4}
end
local function m(strings, ...)
    local substitutions = {...}
    local plainResult = {}
    local richResult = {""}
    local firstColor = nil
    local isString = true
    for i = 1, #strings * 2 - 1 do
        do
            local ____temp_0
            if i % 2 == 0 then
                ____temp_0 = strings[i / 2 + 1]
            else
                ____temp_0 = substitutions[(i - 1) / 2 + 1]
            end
            local element = ____temp_0
            if element == nil then
                goto __continue9
            end
            local color
            local part
            if type(element) == "table" then
                if element.object_name ~= nil then
                    part = element
                else
                    part = element.text
                    color = element.color
                    if firstColor == nil then
                        firstColor = color
                    end
                end
            else
                part = element
            end
            if color then
                richResult[#richResult + 1] = ColorFormat[color]
            end
            local partIsStr = type(part) == "string"
            if not partIsStr and isString then
                richResult = {
                    "",
                    table.concat(richResult)
                }
                isString = false
            end
            plainResult[#plainResult + 1] = partIsStr and part or "<Profiler>"
            richResult[#richResult + 1] = part
            if color then
                richResult[#richResult + 1] = "[/color]"
            end
        end
        ::__continue9::
    end
    return {
        richText = richResult,
        plainText = table.concat(plainResult),
        firstColor = firstColor
    }
end
local messageHandlers = {}
function ____exports.addMessageHandler(handler)
    messageHandlers[#messageHandlers + 1] = handler
end
local function output(message, source)
    for ____, logHandler in ipairs(messageHandlers) do
        logHandler(message, source)
    end
end
local daOutputEvent
if debugAdapterEnabled then
    if __DebugAdapter == nil then
        __DebugAdapter = {
            stepIgnore = function(f) return f end,
            stepIgnoreAll = function(f) return f end
        }
    end
    daOutputEvent = require("__debugadapter__.print").outputEvent
end
local DebugAdapterCategories = {
    [1] = "stdout",
    [2] = "stdout",
    [3] = "console",
    [4] = "stderr",
    [5] = "console"
}
local function printDebugAdapterText(text, source, category)
    local lines = __TS__StringSplit(text, "\n")
    for ____, line in ipairs(lines) do
        local sourceFile
        local sourceLine
        if source then
            sourceFile = source.file
            sourceLine = source.line
            source = nil
        else
            local ____, ____, file1, line1 = string.find(line, "(__[%w%-_]+__/.-%.%a+):(%d*)")
            sourceFile = file1
            sourceLine = tonumber(line1)
        end
        if sourceFile and not __TS__StringStartsWith(sourceFile, "@") then
            sourceFile = "@" .. sourceFile
        end
        daOutputEvent({category = category, output = line})
        daOutputEvent({category = category, output = "\n"}, sourceFile ~= nil and ({source = sourceFile, currentline = sourceLine or 1}) or nil)
    end
end
____exports.debugAdapterLogger = function(message, source)
    local color = message.firstColor or 1
    local category = DebugAdapterCategories[color]
    printDebugAdapterText(message.plainText, source, category)
end
____exports.logLogger = function(message)
    print("FACTORIO-TEST-MESSAGE-START")
    log(message.plainText)
    print("FACTORIO-TEST-MESSAGE-END")
end
____exports.logListener = function(event, state)
    repeat
        local ____switch34 = event.type
        local ____cond34 = ____switch34 == "testRunStarted"
        if ____cond34 then
            do
                output(m({[1] = "Starting test run...", raw = {"Starting test run..."}}))
                break
            end
        end
        ____cond34 = ____cond34 or ____switch34 == "testPassed"
        if ____cond34 then
            do
                if state.config.log_passed_tests then
                    local ____event_1 = event
                    local test = ____event_1.test
                    output(
                        m(
                            {
                                [1] = "",
                                [2] = " ",
                                [3] = " (",
                                [4] = "",
                                [5] = ")",
                                raw = {
                                    "",
                                    " ",
                                    " (",
                                    "",
                                    ")"
                                }
                            },
                            green("PASS"),
                            test.path,
                            test.profiler,
                            (test.tags.after_reload_mods ~= nil or test.tags.after_reload_script ~= nil) and " after reload" or ""
                        ),
                        test.source
                    )
                end
                break
            end
        end
        ____cond34 = ____cond34 or ____switch34 == "testFailed"
        if ____cond34 then
            do
                local ____event_2 = event
                local test = ____event_2.test
                output(
                    m(
                        {[1] = "", [2] = " ", [3] = "", raw = {"", " ", ""}},
                        red("FAIL"),
                        test.path
                    ),
                    test.source
                )
                for ____, ____error in ipairs(test.errors) do
                    output(formatError(____error))
                end
                break
            end
        end
        ____cond34 = ____cond34 or ____switch34 == "testTodo"
        if ____cond34 then
            do
                local ____event_3 = event
                local test = ____event_3.test
                output(
                    m(
                        {[1] = "", [2] = " ", [3] = "", raw = {"", " ", ""}},
                        purple("TODO"),
                        test.path
                    ),
                    test.source
                )
                break
            end
        end
        ____cond34 = ____cond34 or ____switch34 == "testSkipped"
        if ____cond34 then
            do
                if state.config.log_skipped_tests then
                    local ____event_4 = event
                    local test = ____event_4.test
                    output(
                        m(
                            {[1] = "", [2] = " ", [3] = "", raw = {"", " ", ""}},
                            yellow("SKIP"),
                            test.path
                        ),
                        test.source
                    )
                end
                break
            end
        end
        ____cond34 = ____cond34 or ____switch34 == "describeBlockFailed"
        if ____cond34 then
            do
                local ____event_5 = event
                local block = ____event_5.block
                output(
                    m(
                        {[1] = "", [2] = " ", [3] = "", raw = {"", " ", ""}},
                        red("ERROR"),
                        block.path
                    ),
                    block.source
                )
                for ____, ____error in ipairs(block.errors) do
                    output(formatError(____error))
                end
                break
            end
        end
        ____cond34 = ____cond34 or ____switch34 == "testRunFinished"
        if ____cond34 then
            do
                local results = state.results
                local status = results.status
                output(m(
                    {[1] = "", [2] = "", raw = {"", ""}},
                    {
                        text = "Test run finished: " .. tostring(status == "todo" and "passed with todo tests" or status),
                        color = status == "passed" and 2 or (status == "failed" and 4 or (status == "todo" and 5 or 1))
                    }
                ))
                output(m({[1] = "", [2] = "", [3] = "", raw = {"", "", ""}}, state.profiler, state.reloaded and " since last reload" or ""))
                break
            end
        end
        ____cond34 = ____cond34 or ____switch34 == "loadError"
        if ____cond34 then
            do
                output(m(
                    {[1] = "", [2] = " There was an load error:", raw = {"", " There was an load error:"}},
                    red("ERROR")
                ))
                output(formatError(state.rootBlock.errors[1]))
                break
            end
        end
    until true
end
return ____exports
 end,
["builtin-test-event-listeners"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____output = require("output")
local logListener = ____output.logListener
local ____results = require("results")
local resultCollector = ____results.resultCollector
local ____state = require("state")
local cleanupTestState = ____state.cleanupTestState
local function setupListener(event, state)
    if event.type == "testRunStarted" then
        game.speed = state.config.game_speed
        game.autosave_enabled = false
        local ____this_1
        ____this_1 = state.config
        local ____opt_0 = ____this_1.before_test_run
        if ____opt_0 ~= nil then
            ____opt_0(____this_1)
        end
    elseif event.type == "testRunFinished" then
        game.speed = 1
        local status = state.results.status
        if state.config.sound_effects then
            local passed = status == "passed" or status == "todo"
            if passed then
                game.play_sound({path = "utility/game_won"})
            else
                game.play_sound({path = "utility/game_lost"})
            end
        end
        local ____this_3
        ____this_3 = state.config
        local ____opt_2 = ____this_3.after_test_run
        if ____opt_2 ~= nil then
            ____opt_2(____this_3)
        end
        cleanupTestState()
        print("FACTORIO-TEST-RESULT:" .. tostring(status))
    elseif event.type == "loadError" then
        game.speed = 1
        game.play_sound({path = "utility/console_message"})
        print("FACTORIO-TEST-RESULT:loadError")
    end
end
____exports.builtinTestEventListeners = {resultCollector, setupListener, logListener}
return ____exports
 end,
["config"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local ____exports = {}
function ____exports.fillConfig(config)
    return __TS__ObjectAssign({
        default_timeout = 60 * 60,
        default_ticks_between_tests = 1,
        game_speed = 1000,
        log_passed_tests = true,
        log_skipped_tests = false,
        sound_effects = false,
        load_luassert = true
    }, config)
end
return ____exports
 end,
["test-gui"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local updateTestCounts
local ____output = require("output")
local Colors = ____output.Colors
local ____tests = require("tests")
local countActiveTests = ____tests.countActiveTests
function updateTestCounts(gui, results)
    gui.progressBar.value = gui.totalTests == 0 and 1 or results.ran / gui.totalTests
    gui.progressLabel.caption = {"", results.ran, "/", gui.totalTests}
    local testCounts = gui.testCounts.children
    if results.failed > 0 then
        testCounts[1].caption = {"factorio-test.progress-gui.n-failed", results.failed}
    end
    if results.describeBlockErrors > 0 then
        testCounts[2].caption = {"factorio-test.progress-gui.n-errors", results.describeBlockErrors}
    end
    if results.skipped > 0 then
        testCounts[3].caption = {"factorio-test.progress-gui.n-skipped", results.skipped}
    end
    if results.todo > 0 then
        testCounts[4].caption = {"factorio-test.progress-gui.n-todo", results.todo}
    end
    if results.passed > 0 then
        testCounts[5].caption = {"factorio-test.progress-gui.n-passed", results.passed}
    end
end
local function StatusText(parent)
    local statusText = parent.add({type = "label"})
    statusText.style.font = "default-large"
    return statusText
end
local function ProgressBar(parent)
    local progressFlow = parent.add({type = "flow", direction = "horizontal"})
    progressFlow.style.horizontally_stretchable = true
    progressFlow.style.vertical_align = "center"
    local progressBar = progressFlow.add({type = "progressbar"})
    progressBar.style.horizontally_stretchable = true
    local progressLabel = progressFlow.add({type = "label"})
    local plStyle = progressLabel.style
    plStyle.width = 80
    plStyle.horizontal_align = "center"
    return {progressBar = progressBar, progressLabel = progressLabel}
end
local function TestCount(parent)
    local ____table = parent.add({type = "table", column_count = 5, style = "bordered_table"})
    local function addLabel()
        local result = ____table.add({type = "label"})
        local style = result.style
        style.horizontally_stretchable = true
        style.horizontal_align = "center"
        style.font = "default-bold"
        style.width = 80
        return result
    end
    local colors = {
        4,
        4,
        3,
        5,
        2
    }
    for ____, color in ipairs(colors) do
        local label = addLabel()
        label.style.font_color = Colors[color]
    end
    return ____table
end
local function TestOutput(parent)
    local frame = parent.add({type = "frame", style = "inside_shallow_frame", direction = "vertical"})
    local pane = frame.add({type = "scroll-pane", style = "scroll_pane_in_shallow_frame"})
    pane.style.height = 600
    pane.style.horizontally_stretchable = true
    return pane
end
local function bottomButtonsBar(parent)
    local flow = parent.add({type = "flow", direction = "horizontal"})
    local spacer = flow.add({type = "empty-widget"})
    spacer.style.horizontally_stretchable = true
    local rerunButton = flow.add({type = "button", caption = {"factorio-test.config-gui.rerun-tests"}, tags = {modName = "factorio-test", on_gui_click = "start-tests"}, enabled = false})
    return {rerunButton = rerunButton}
end
local function getPlayer()
    for ____, player in pairs(game.players) do
        return player
    end
    error("Could not find any players!")
end
local function closeTestProgressGui()
    local player = getPlayer()
    local screen = player.gui.screen
    local ____opt_0 = screen["factorio-test-test-gui"]
    if ____opt_0 ~= nil then
        ____opt_0.destroy()
    end
    storage.__testGui = nil
end
local function createTestProgressGui(state)
    local player = getPlayer()
    local screen = player.gui.screen
    local ____opt_2 = screen["factorio-test-test-gui"]
    if ____opt_2 ~= nil then
        ____opt_2.destroy()
    end
    local mainFrame = screen.add({type = "frame", name = "factorio-test-test-gui", direction = "vertical"})
    mainFrame.auto_center = true
    mainFrame.style.width = 1000
    local titleBar = mainFrame.add({type = "flow", direction = "horizontal"})
    titleBar.drag_target = mainFrame
    local style = titleBar.style
    style.horizontal_spacing = 8
    style.height = 28
    titleBar.add({type = "label", caption = {"factorio-test.progress-gui.title", script.mod_name}, style = "frame_title", ignored_by_interaction = true})
    do
        local element = titleBar.add({type = "empty-widget", ignored_by_interaction = true, style = "draggable_space"})
        local style = element.style
        style.horizontally_stretchable = true
        style.height = 24
    end
    local closeButton = titleBar.add({
        type = "sprite-button",
        style = "frame_action_button",
        sprite = "utility/close",
        hovered_sprite = "utility/close_black",
        clicked_sprite = "utility/close_black",
        tooltip = {"gui.close"},
        mouse_button_filter = {"left"},
        tags = {modName = "factorio-test", on_gui_click = "close-test-gui"},
        enabled = false
    })
    local contentFlow = mainFrame.add({type = "flow", direction = "vertical"})
    contentFlow.style.vertical_spacing = 15
    local topFrame = contentFlow.add({type = "frame", style = "inside_shallow_frame_with_padding", direction = "vertical"})
    local gui = __TS__ObjectAssign(
        {
            player = player,
            mainFrame = mainFrame,
            totalTests = countActiveTests(state.rootBlock, state),
            closeButton = closeButton,
            statusText = StatusText(topFrame)
        },
        ProgressBar(topFrame),
        {
            testCounts = TestCount(topFrame),
            output = TestOutput(contentFlow)
        },
        bottomButtonsBar(contentFlow)
    )
    updateTestCounts(gui, state.results)
    return gui
end
local function getTestProgressGui()
    local gui = storage.__testGui
    if not (gui and gui.mainFrame.valid) then
        storage.__testGui = nil
        return nil
    end
    return gui
end
____exports.progressGuiListener = function(event, state)
    if event.type == "testRunStarted" then
        storage.__testGui = createTestProgressGui(state)
        return
    end
    local gui = getTestProgressGui()
    if not gui then
        return
    end
    repeat
        local ____switch26 = event.type
        local ____cond26 = ____switch26 == "describeBlockEntered"
        if ____cond26 then
            do
                local ____event_6 = event
                local block = ____event_6.block
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", block.path}
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "testEntered"
        if ____cond26 then
            do
                local ____event_7 = event
                local test = ____event_7.test
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", test.path}
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "testFailed"
        if ____cond26 then
            do
                updateTestCounts(gui, state.results)
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", event.test.parent.path}
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "testPassed"
        if ____cond26 then
            do
                updateTestCounts(gui, state.results)
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", event.test.parent.path}
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "testSkipped"
        if ____cond26 then
            do
                updateTestCounts(gui, state.results)
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", event.test.parent.path}
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "testTodo"
        if ____cond26 then
            do
                updateTestCounts(gui, state.results)
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", event.test.parent.path}
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "describeBlockFinished"
        if ____cond26 then
            do
                local ____event_8 = event
                local block = ____event_8.block
                if block.parent then
                    gui.statusText.caption = {"factorio-test.progress-gui.running-test", block.parent.path}
                end
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "describeBlockFailed"
        if ____cond26 then
            do
                updateTestCounts(gui, state.results)
                local ____event_9 = event
                local block = ____event_9.block
                if block.parent then
                    gui.statusText.caption = {"factorio-test.progress-gui.running-test", block.parent.path}
                end
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "testRunFinished"
        if ____cond26 then
            do
                local statusLocale = state.results.status == "passed" and "factorio-test.progress-gui.tests-passed" or (state.results.status == "todo" and "factorio-test.progress-gui.tests-passed-with-todo" or "factorio-test.progress-gui.tests-failed")
                gui.statusText.caption = {statusLocale}
                gui.closeButton.enabled = true
                gui.rerunButton.enabled = true
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "loadError"
        if ____cond26 then
            do
                gui.statusText.caption = {"factorio-test.progress-gui.load-error"}
                gui.closeButton.enabled = true
                break
            end
        end
        ____cond26 = ____cond26 or ____switch26 == "customEvent"
        if ____cond26 then
            do
                if event.name == "closeProgressGui" then
                    closeTestProgressGui()
                end
                break
            end
        end
    until true
end
local profilerLength = #"(Duration: 0.082400ms)" - #"(<Profiler>)"
____exports.progressGuiLogger = function(message)
    local gui = storage.__testGui
    if not gui or not gui.progressBar.valid then
        return
    end
    local output = gui.output
    local textBox = output.add({type = "text-box", style = "factorio-test-test-output-box-style"})
    textBox.read_only = true
    textBox.word_wrap = true
    local lines = 0
    local isFirstLine = true
    for ____, line in ipairs(__TS__StringSplit(message.plainText, "\n")) do
        local lineLength = #line + (isFirstLine and profilerLength or 0)
        if lineLength > 110 then
            lines = lines + math.ceil(lineLength / 105)
        else
            lines = lines + 1
        end
        isFirstLine = false
    end
    textBox.style.height = 20 * lines
    textBox.caption = message.richText
end
return ____exports
 end,
["reload-resume"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArrayEvery = ____lualib.__TS__ArrayEvery
local ____exports = {}
local ____util = require("util")
local ____table = ____util.table
local compare = ____table.compare
local function saveTest(test)
    local result = {
        type = "test",
        path = test.path,
        tags = test.tags,
        source = test.source,
        numParts = #test.parts,
        mode = test.mode,
        ticksBefore = test.ticksBefore,
        errors = test.errors,
        profiler = test.profiler
    }
    test.parts = nil
    return result
end
local function saveDescribeBlock(block)
    local result = {
        type = "describeBlock",
        path = block.path,
        tags = block.tags,
        source = block.source,
        children = __TS__ArrayMap(
            block.children,
            function(____, child) return child.type == "test" and saveTest(child) or saveDescribeBlock(child) end
        ),
        hookTypes = __TS__ArrayMap(
            block.hooks,
            function(____, hook) return hook.type end
        ),
        mode = block.mode,
        ticksBetweenTests = block.ticksBetweenTests,
        errors = block.errors
    }
    block.hooks = nil
    return result
end
local savedTestPath
local foundMatchingTest
local function compareToSavedTest(saved, current)
    if saved.path ~= current.path then
        return false
    end
    if not compare(saved.tags, current.tags) then
        return false
    end
    if not compare(saved.source, current.source) then
        return false
    end
    if saved.numParts ~= #current.parts then
        return false
    end
    if saved.mode ~= current.mode then
        return false
    end
    if saved.ticksBefore ~= current.ticksBefore then
        return false
    end
    current.errors = saved.errors
    current.profiler = saved.profiler
    if current.path == savedTestPath then
        foundMatchingTest = current
    end
    return true
end
local function compareToSavedDescribeBlock(saved, current)
    if saved.path ~= current.path then
        return false
    end
    if not compare(saved.tags, current.tags) then
        return false
    end
    if not compare(saved.source, current.source) then
        return false
    end
    if not compare(
        saved.hookTypes,
        __TS__ArrayMap(
            current.hooks,
            function(____, hook) return hook.type end
        )
    ) then
        return false
    end
    if saved.mode ~= current.mode then
        return false
    end
    if saved.ticksBetweenTests ~= current.ticksBetweenTests then
        return false
    end
    local childrenMatch = __TS__ArrayEvery(
        saved.children,
        function(____, child, i)
            local currentChild = current.children[i + 1]
            if not currentChild or currentChild.type ~= child.type then
                return false
            end
            local ____temp_0
            if child.type == "test" then
                ____temp_0 = compareToSavedTest(child, currentChild)
            else
                ____temp_0 = compareToSavedDescribeBlock(child, currentChild)
            end
            return ____temp_0
        end
    )
    if not childrenMatch then
        return false
    end
    current.errors = saved.errors
    return true
end
function ____exports.prepareReload(testState)
    local currentRun = testState.currentTestRun
    storage.__testResume = {
        rootBlock = saveDescribeBlock(testState.rootBlock),
        results = testState.results,
        resumeTestPath = currentRun.test.path,
        resumePartIndex = currentRun.partIndex + 1,
        profiler = testState.profiler
    }
    testState.rootBlock = nil
    testState.currentTestRun = nil
    testState.setTestStage("ReloadingMods")
end
function ____exports.resumeAfterReload(state)
    local testResume = storage.__testResume or error("attempting to resume after reload without resume data saved")
    storage.__testResume = nil
    state.results = testResume.results
    state.profiler = testResume.profiler
    state.reloaded = true
    local saved = testResume.rootBlock
    savedTestPath = testResume.resumeTestPath
    foundMatchingTest = nil
    local matches = compareToSavedDescribeBlock(saved, state.rootBlock)
    local test = foundMatchingTest
    foundMatchingTest = nil
    savedTestPath = nil
    if matches and test then
        return {test = test, partIndex = testResume.resumePartIndex}
    end
end
return ____exports
 end,
["runner"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__New = ____lualib.__TS__New
local __TS__Class = ____lualib.__TS__Class
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayPushArray = ____lualib.__TS__ArrayPushArray
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArraySome = ____lualib.__TS__ArraySome
local ____exports = {}
local TestRunnerImpl
local _____util = require("_util")
local __factorio_test__pcallWithStacktrace = _____util.__factorio_test__pcallWithStacktrace
local assertNever = _____util.assertNever
local ____reload_2Dresume = require("reload-resume")
local resumeAfterReload = ____reload_2Dresume.resumeAfterReload
local ____state = require("state")
local setToLoadErrorState = ____state.setToLoadErrorState
local ____tests = require("tests")
local formatSource = ____tests.formatSource
local isSkippedTest = ____tests.isSkippedTest
function ____exports.createTestRunner(state)
    return __TS__New(TestRunnerImpl, state)
end
TestRunnerImpl = __TS__Class()
TestRunnerImpl.name = "TestRunnerImpl"
function TestRunnerImpl.prototype.____constructor(self, state)
    self.state = state
    self.ticksToWait = 0
    self.nextTask = {task = "init"}
end
function TestRunnerImpl.prototype.tick(self)
    if self.ticksToWait > 0 then
        local ____self_0, ____ticksToWait_1 = self, "ticksToWait"
        local ____self_ticksToWait_2 = ____self_0[____ticksToWait_1] - 1
        ____self_0[____ticksToWait_1] = ____self_ticksToWait_2
        if ____self_ticksToWait_2 > 0 then
            return
        end
    end
    while self.nextTask do
        self.nextTask = self:runTask(self.nextTask)
        if self.nextTask then
            self.ticksToWait = self.nextTask.waitTicks or 0
        end
        if self.ticksToWait > 0 then
            return
        end
    end
end
function TestRunnerImpl.prototype.isDone(self)
    return self.nextTask == nil
end
function TestRunnerImpl.prototype.runTask(self, task)
    local nextTask = self[task.task](self, task.data)
    if nextTask then
        self.ticksToWait = nextTask.waitTicks or 0
    end
    return nextTask
end
function TestRunnerImpl.prototype.init(self)
    if game.is_multiplayer() then
        error("Tests cannot be in run in multiplayer")
    end
    local stage = self.state.getTestStage()
    if stage == "NotRun" or stage == "Ready" then
        return self:startTestRun()
    elseif stage == "ReloadingMods" then
        return self:attemptResumeAfterReload()
    elseif stage == "Running" then
        return self:createLoadError("Save was unexpectedly reloaded while tests were running. This will cause tests to break. Aborting test run.")
    elseif stage == "Finished" or stage == "LoadError" then
        return self:rerun()
    end
    assertNever(stage)
end
function TestRunnerImpl.prototype.startTestRun(self)
    local state = self.state
    state.profiler = game.create_profiler()
    state.setTestStage("Running")
    state:raiseTestEvent({type = "testRunStarted"})
    return {task = "enterDescribe", data = state.rootBlock}
end
function TestRunnerImpl.prototype.attemptResumeAfterReload(self)
    local resumePoint = resumeAfterReload(self.state)
    if not resumePoint then
        return self:createLoadError("Mod files were changed after reload. Aborting test run.")
    end
    local test = resumePoint.test
    local partIndex = resumePoint.partIndex
    self.state.setTestStage("Running")
    return {
        task = "runTestPart",
        data = TestRunnerImpl:newTestRun(test, partIndex)
    }
end
function TestRunnerImpl.prototype.rerun(self)
    local state = self.state
    local ____state_config_3, ____tag_blacklist_4 = state.config, "tag_blacklist"
    if ____state_config_3[____tag_blacklist_4] == nil then
        ____state_config_3[____tag_blacklist_4] = {}
    end
    local tagBlacklist = state.config.tag_blacklist
    if __TS__ArrayIndexOf(tagBlacklist, "no_rerun") == -1 then
        tagBlacklist[#tagBlacklist + 1] = "no_rerun"
    end
    return self:startTestRun()
end
function TestRunnerImpl.prototype.enterDescribe(self, block)
    self.state:raiseTestEvent({type = "describeBlockEntered", block = block})
    if #block.errors ~= 0 then
        return {task = "leaveDescribeBlock", data = block}
    end
    if #block.children == 0 then
        local ____block_errors_6 = block.errors
        ____block_errors_6[#____block_errors_6 + 1] = "No tests defined"
    end
    if self:hasAnyTest(block) then
        local hooks = __TS__ArrayFilter(
            block.hooks,
            function(____, x) return x.type == "beforeAll" end
        )
        for ____, hook in ipairs(hooks) do
            local success, message = __factorio_test__pcallWithStacktrace(hook.func)
            if not success then
                local ____block_errors_7 = block.errors
                ____block_errors_7[#____block_errors_7 + 1] = (("Error running " .. hook.type) .. ": ") .. tostring(message)
            end
        end
    end
    return TestRunnerImpl:getNextDescribeBlockTask(block, 0)
end
function TestRunnerImpl.prototype.enterTest(self, test)
    self.state:raiseTestEvent({type = "testEntered", test = test})
    if isSkippedTest(test, self.state) then
        if test.mode == "todo" then
            self.state:raiseTestEvent({type = "testTodo", test = test})
        else
            self.state:raiseTestEvent({type = "testSkipped", test = test})
        end
        return TestRunnerImpl:getNextDescribeBlockTask(test.parent, test.indexInParent + 1)
    end
    return {task = "startTest", data = test, waitTicks = test.ticksBefore}
end
function TestRunnerImpl.prototype.startTest(self, test)
    test.profiler = game.create_profiler()
    local testRun = TestRunnerImpl:newTestRun(test, 0)
    self.state.currentTestRun = testRun
    self.state:raiseTestEvent({type = "testStarted", test = test})
    local function collectHooks(block, hooks)
        if block.parent then
            collectHooks(block.parent, hooks)
        end
        __TS__ArrayPushArray(
            hooks,
            __TS__ArrayFilter(
                block.hooks,
                function(____, x) return x.type == "beforeEach" end
            )
        )
        return hooks
    end
    local beforeEach = collectHooks(test.parent, {})
    for ____, hook in ipairs(beforeEach) do
        if #test.errors ~= 0 then
            break
        end
        local success, ____error = __factorio_test__pcallWithStacktrace(hook.func)
        if not success then
            local ____test_errors_8 = test.errors
            ____test_errors_8[#____test_errors_8 + 1] = ____error
        end
    end
    return {task = "runTestPart", data = testRun}
end
function TestRunnerImpl.prototype.runTestPart(self, testRun)
    local ____testRun_9 = testRun
    local test = ____testRun_9.test
    local partIndex = ____testRun_9.partIndex
    local part = test.parts[partIndex + 1]
    self.state.currentTestRun = testRun
    if #test.errors == 0 then
        local success, ____error = __factorio_test__pcallWithStacktrace(part.func)
        if not success then
            local ____test_errors_10 = test.errors
            ____test_errors_10[#____test_errors_10 + 1] = ____error
        end
    end
    return TestRunnerImpl:nextTestTask(testRun)
end
function TestRunnerImpl.prototype.waitForTestPart(self, testRun)
    local ____testRun_11 = testRun
    local test = ____testRun_11.test
    local partIndex = ____testRun_11.partIndex
    local tickNumber = game.tick - testRun.tickStarted
    local timeout = testRun.timeout
    if tickNumber > timeout then
        local ____test_errors_12 = test.errors
        ____test_errors_12[#____test_errors_12 + 1] = (("Test timed out after " .. tostring(timeout)) .. " ticks:\n") .. formatSource(test.parts[partIndex + 1].source)
    end
    if #test.errors == 0 then
        for ____, func in ipairs(__TS__ObjectKeys(testRun.onTickFuncs)) do
            local success, result = __factorio_test__pcallWithStacktrace(func, tickNumber)
            if not success then
                local ____test_errors_13 = test.errors
                ____test_errors_13[#____test_errors_13 + 1] = result
                break
            elseif result == false then
                testRun.onTickFuncs[func] = nil
            end
        end
    end
    return TestRunnerImpl:nextTestTask(testRun)
end
function TestRunnerImpl.prototype.leaveTest(self, testRun)
    local ____testRun_14 = testRun
    local test = ____testRun_14.test
    local afterTestFuncs = ____testRun_14.afterTestFuncs
    local function collectHooks(block, hooks)
        __TS__ArrayPushArray(
            hooks,
            __TS__ArrayMap(
                __TS__ArrayFilter(
                    block.hooks,
                    function(____, x) return x.type == "afterEach" end
                ),
                function(____, x) return x.func end
            )
        )
        if block.parent then
            collectHooks(block.parent, hooks)
        end
        return hooks
    end
    local afterEach = collectHooks(
        test.parent,
        {table.unpack(afterTestFuncs)}
    )
    for ____, hook in ipairs(afterEach) do
        local success, ____error = __factorio_test__pcallWithStacktrace(hook)
        if not success then
            local ____test_errors_15 = test.errors
            ____test_errors_15[#____test_errors_15 + 1] = ____error
        end
    end
    self.state.currentTestRun = nil
    test.profiler.stop()
    if #test.errors > 0 then
        self.state:raiseTestEvent({type = "testFailed", test = test})
    else
        self.state:raiseTestEvent({type = "testPassed", test = test})
    end
    return TestRunnerImpl:getNextDescribeBlockTask(test.parent, test.indexInParent + 1)
end
function TestRunnerImpl.prototype.leaveDescribeBlock(self, block)
    local hasTests = self:hasAnyTest(block)
    if hasTests then
        local hooks = __TS__ArrayFilter(
            block.hooks,
            function(____, x) return x.type == "afterAll" end
        )
        for ____, hook in ipairs(hooks) do
            local success, message = __factorio_test__pcallWithStacktrace(hook.func)
            if not success then
                local ____block_errors_16 = block.errors
                ____block_errors_16[#____block_errors_16 + 1] = (("Error running " .. hook.type) .. ": ") .. tostring(message)
            end
        end
    end
    if #block.errors > 0 then
        self.state:raiseTestEvent({type = "describeBlockFailed", block = block})
    else
        self.state:raiseTestEvent({type = "describeBlockFinished", block = block})
    end
    return block.parent and TestRunnerImpl:getNextDescribeBlockTask(block.parent, block.indexInParent + 1) or ({task = "finishTestRun"})
end
function TestRunnerImpl.prototype.finishTestRun(self)
    local state = self.state
    local ____opt_17 = state.profiler
    if ____opt_17 ~= nil then
        ____opt_17.stop()
    end
    state.setTestStage("Finished")
    state:raiseTestEvent({type = "testRunFinished"})
    return nil
end
function TestRunnerImpl.getNextDescribeBlockTask(self, block, index)
    if #block.errors > 0 then
        return {task = "leaveDescribeBlock", data = block}
    end
    local item = block.children[index + 1]
    if item then
        return item.type == "describeBlock" and ({task = "enterDescribe", data = item}) or ({task = "enterTest", data = item})
    end
    return {task = "leaveDescribeBlock", data = block}
end
function TestRunnerImpl.prototype.hasAnyTest(self, block)
    return __TS__ArraySome(
        block.children,
        function(____, child)
            local ____temp_19
            if child.type == "test" then
                ____temp_19 = not isSkippedTest(child, self.state)
            else
                ____temp_19 = self:hasAnyTest(child)
            end
            return ____temp_19
        end
    )
end
function TestRunnerImpl.prototype.createLoadError(self, message)
    setToLoadErrorState(self.state, message)
    self.state:raiseTestEvent({type = "loadError"})
    return nil
end
function TestRunnerImpl.nextTestTask(self, testRun)
    local ____testRun_20 = testRun
    local test = ____testRun_20.test
    local partIndex = ____testRun_20.partIndex
    if #test.errors ~= 0 or not testRun.async or testRun.asyncDone or not testRun.explicitAsync and (next(testRun.onTickFuncs)) == nil then
        if partIndex + 1 < #test.parts then
            return {
                task = "runTestPart",
                data = TestRunnerImpl:newTestRun(test, partIndex + 1)
            }
        end
        return {task = "leaveTest", data = testRun}
    end
    return {task = "waitForTestPart", data = testRun, waitTicks = 1}
end
function TestRunnerImpl.newTestRun(self, test, partIndex)
    return {
        test = test,
        async = false,
        timeout = 0,
        asyncDone = false,
        tickStarted = game.tick,
        onTickFuncs = {},
        afterTestFuncs = {},
        partIndex = partIndex
    }
end
return ____exports
 end,
["setup-globals"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArraySome = ____lualib.__TS__ArraySome
local __TS__ArrayIsArray = ____lualib.__TS__ArrayIsArray
local __TS__ArrayEvery = ____lualib.__TS__ArrayEvery
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local async
local util = require("util")
local ____reload_2Dresume = require("reload-resume")
local prepareReload = ____reload_2Dresume.prepareReload
local ____state = require("state")
local getCurrentBlock = ____state.getCurrentBlock
local getTestState = ____state.getTestState
local ____tests = require("tests")
local addDescribeBlock = ____tests.addDescribeBlock
local addTest = ____tests.addTest
local createSource = ____tests.createSource
local _____util = require("_util")
local __factorio_test__pcallWithStacktrace = _____util.__factorio_test__pcallWithStacktrace
function ____exports.getCurrentTestRun()
    return getTestState().currentTestRun or error("This can only be called within a test")
end
function async(timeout)
    local testRun = ____exports.getCurrentTestRun()
    testRun.async = true
    testRun.explicitAsync = true
    if not timeout then
        timeout = getTestState().config.default_timeout
    end
    if timeout < 1 then
        error("test timeout must be greater than 0")
    end
    testRun.timeout = timeout
    testRun.async = true
end
local function getCallerSource(upStack)
    if upStack == nil then
        upStack = 1
    end
    local info = debug.getinfo(upStack + 2, "Sl") or ({})
    return createSource(info.source, info.currentline)
end
local function addHook(____type, func)
    local state = getTestState()
    if state.currentTestRun then
        error(((("Hook (" .. ____type) .. ") cannot be nested inside test \"") .. state.currentTestRun.test.path) .. "\"")
    end
    local ____getCurrentBlock_result_hooks_0 = getCurrentBlock().hooks
    ____getCurrentBlock_result_hooks_0[#____getCurrentBlock_result_hooks_0 + 1] = {type = ____type, func = func}
end
local function afterTest(func)
    local ____exports_getCurrentTestRun_result_afterTestFuncs_1 = ____exports.getCurrentTestRun().afterTestFuncs
    ____exports_getCurrentTestRun_result_afterTestFuncs_1[#____exports_getCurrentTestRun_result_afterTestFuncs_1 + 1] = func
end
local function consumeTags()
    local state = getTestState()
    local result = state.currentTags
    state.currentTags = nil
    return result or ({})
end
local function createTest(name, func, mode, upStack)
    if upStack == nil then
        upStack = 1
    end
    local state = getTestState()
    if state.currentTestRun then
        error(((("Test \"" .. name) .. "\" cannot be nested inside test \"") .. state.currentTestRun.test.path) .. "\"")
    end
    local parent = getCurrentBlock()
    return addTest(
        parent,
        name,
        getCallerSource(upStack + 1),
        func,
        mode,
        util.merge({
            consumeTags(),
            parent.tags
        })
    )
end
local function addPart(test, func, funcForSource)
    if funcForSource == nil then
        funcForSource = func
    end
    local info = debug.getinfo(funcForSource, "Sl")
    local source = createSource(info.source, info.linedefined)
    local ____test_parts_2 = test.parts
    ____test_parts_2[#____test_parts_2 + 1] = {func = func, source = source}
end
local function createTestBuilder(addPart, addTag)
    local result
    local function reloadFunc(reload, what, tag)
        return function(func)
            addPart(function()
                async(1)
                prepareReload(getTestState())
                reload()
            end)
            addPart(func)
            addTag(tag)
            return result
        end
    end
    result = {
        after_reload_script = reloadFunc(
            function() return game.reload_script() end,
            "script",
            "after_reload_script"
        ),
        after_reload_mods = reloadFunc(
            function() return game.reload_mods() end,
            "mods",
            "after_reload_mods"
        )
    }
    return result
end
local function skipAllChildren(block)
    for ____, child in ipairs(block.children) do
        child.mode = "skip"
        if child.declaredMode ~= "skip" then
            if child.type == "describeBlock" then
                skipAllChildren(child)
            end
        end
    end
end
local function focusAllChildren(block)
    for ____, child in ipairs(block.children) do
        if child.declaredMode == nil then
            child.mode = "only"
            if child.type == "describeBlock" then
                focusAllChildren(child)
            end
        else
            child.mode = child.declaredMode
        end
    end
end
local function markFocusedTests(state, block)
    for ____, child in ipairs(block.children) do
        if child.declaredMode == "only" then
            state.hasFocusedTests = true
        end
    end
end
function ____exports.propagateTestMode(state, describeBlock, mode)
    if mode == "skip" then
        skipAllChildren(describeBlock)
    elseif mode == "only" then
        state.hasFocusedTests = true
        if not __TS__ArraySome(
            describeBlock.children,
            function(____, child) return child.mode == "only" end
        ) then
            focusAllChildren(describeBlock)
        else
            markFocusedTests(state, describeBlock)
        end
    else
        markFocusedTests(state, describeBlock)
    end
end
local function createDescribe(name, block, mode, upStack)
    if upStack == nil then
        upStack = 1
    end
    local state = getTestState()
    if state.currentTestRun then
        error(((("Describe block \"" .. name) .. "\" cannot be nested inside test \"") .. state.currentTestRun.test.path) .. "\"")
    end
    local source = getCallerSource(upStack + 1)
    local parent = getCurrentBlock()
    local describeBlock = addDescribeBlock(
        parent,
        name,
        source,
        mode,
        util.merge({
            parent.tags,
            consumeTags()
        })
    )
    state.currentBlock = describeBlock
    local success, msg = __factorio_test__pcallWithStacktrace(block)
    if not success then
        local ____describeBlock_errors_3 = describeBlock.errors
        ____describeBlock_errors_3[#____describeBlock_errors_3 + 1] = "Error in definition: " .. tostring(msg)
    end
    ____exports.propagateTestMode(state, describeBlock, mode)
    state.currentBlock = parent
    if state.currentTags then
        local ____describeBlock_errors_4 = describeBlock.errors
        ____describeBlock_errors_4[#____describeBlock_errors_4 + 1] = "Tags not added to any test or describe block: " .. serpent.line(state.currentTags)
        state.currentTags = nil
    end
    return describeBlock
end
local function createEachItems(values, name)
    if #values == 0 then
        error(".each called with no data")
    end
    local valuesAsRows = __TS__ArrayEvery(
        values,
        function(____, v) return __TS__ArrayIsArray(v) end
    ) and values or __TS__ArrayMap(
        values,
        function(____, v) return {v} end
    )
    return __TS__ArrayMap(
        valuesAsRows,
        function(____, row)
            local rowValues = __TS__ArrayMap(
                row,
                function(____, v) return type(v) == "table" and serpent.line(v) or v end
            )
            local itemName = string.format(
                name,
                table.unpack(rowValues)
            )
            return {name = itemName, row = row}
        end
    )
end
local function createTestEach(mode)
    local result = setmetatable(
        {},
        {__call = function(____, name, func)
            local test = createTest(name, func, mode)
            return createTestBuilder(
                function(func1) return addPart(test, func1) end,
                function(tag)
                    test.tags[tag] = true
                    return nil
                end
            )
        end}
    )
    result.each = function(values) return function(name, func)
        local items = createEachItems(values, name)
        local testBuilders = __TS__ArrayMap(
            items,
            function(____, item)
                local test = createTest(
                    item.name,
                    function() return func(table.unpack(item.row)) end,
                    mode,
                    3
                )
                return {test = test, row = item.row}
            end
        )
        return createTestBuilder(
            function(func)
                for ____, ____value in ipairs(testBuilders) do
                    local test = ____value.test
                    local row = ____value.row
                    addPart(
                        test,
                        function()
                            func(table.unpack(row))
                        end,
                        func
                    )
                end
            end,
            function(tag)
                for ____, ____value in ipairs(testBuilders) do
                    local test = ____value.test
                    test.tags[tag] = true
                end
            end
        )
    end end
    return result
end
local function createDescribeEach(mode)
    local result = setmetatable(
        {},
        {__call = function(____, name, func)
            local block = createDescribe(name, func, mode)
            return block
        end}
    )
    result.each = function(values) return function(name, func)
        local items = createEachItems(values, name)
        for ____, ____value in ipairs(items) do
            local row = ____value.row
            local name = ____value.name
            createDescribe(
                name,
                function() return func(table.unpack(row)) end,
                mode,
                2
            )
        end
    end end
    return result
end
local test = createTestEach(nil)
test.skip = createTestEach("skip")
test.only = createTestEach("only")
test.todo = function(name)
    createTest(
        name,
        function()
        end,
        "todo"
    )
end
local describe = createDescribeEach(nil)
describe.skip = createDescribeEach("skip")
describe.only = createDescribeEach("only")
local function tags(...)
    local tags = {...}
    local block = getCurrentBlock()
    local state = getTestState()
    if state.currentTags then
        local ____block_errors_5 = block.errors
        ____block_errors_5[#____block_errors_5 + 1] = "Double call to tags()"
    end
    state.currentTags = util.list_to_map(tags)
end
local function implicitAsync()
    local testRun = ____exports.getCurrentTestRun()
    testRun.async = true
    if not testRun.explicitAsync then
        testRun.timeout = getTestState().config.default_timeout
    end
end
____exports.globals = {
    test = test,
    it = test,
    describe = describe,
    tags = tags,
    before_all = function(func)
        addHook("beforeAll", func)
    end,
    after_all = function(func)
        addHook("afterAll", func)
    end,
    before_each = function(func)
        addHook("beforeEach", func)
    end,
    after_each = function(func)
        addHook("afterEach", func)
    end,
    after_test = function(func)
        afterTest(func)
    end,
    async = async,
    done = function()
        local testRun = ____exports.getCurrentTestRun()
        if not testRun.async then
            error("\"done\" can only be used when test is async")
        end
        testRun.asyncDone = true
    end,
    on_tick = function(func)
        implicitAsync()
        local testRun = ____exports.getCurrentTestRun()
        testRun.onTickFuncs[func] = true
    end,
    after_ticks = function(ticks, func)
        implicitAsync()
        local testRun = ____exports.getCurrentTestRun()
        local finishTick = game.tick - testRun.tickStarted + ticks
        if ticks < 1 then
            error("after_ticks amount must be positive")
        end
        on_tick(function(tick)
            if tick >= finishTick then
                func()
                return false
            end
        end)
    end,
    ticks_between_tests = function(ticks)
        if ticks < 0 then
            error("ticks between tests must be 0 or greater")
        end
        getCurrentBlock().ticksBetweenTests = ticks
    end
}
return ____exports
 end,
["load"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayForEach = ____lualib.__TS__ArrayForEach
local isRunning, loadTests, tryContinueTests, runTests, doRunTests, tapEvent, revertTappedEvents, tappedHandlers, oldScript
local _____util = require("_util")
local debugAdapterEnabled = _____util.debugAdapterEnabled
local ____builtin_2Dtest_2Devent_2Dlisteners = require("builtin-test-event-listeners")
local builtinTestEventListeners = ____builtin_2Dtest_2Devent_2Dlisteners.builtinTestEventListeners
local ____config = require("config")
local fillConfig = ____config.fillConfig
local ____output = require("output")
local addMessageHandler = ____output.addMessageHandler
local debugAdapterLogger = ____output.debugAdapterLogger
local logLogger = ____output.logLogger
local ____test_2Dgui = require("test-gui")
local progressGuiListener = ____test_2Dgui.progressGuiListener
local progressGuiLogger = ____test_2Dgui.progressGuiLogger
local ____runner = require("runner")
local createTestRunner = ____runner.createTestRunner
local ____setup_2Dglobals = require("setup-globals")
local globals = ____setup_2Dglobals.globals
local ____state = require("state")
local getTestState = ____state.getTestState
local onTestStageChanged = ____state.onTestStageChanged
local resetTestState = ____state.resetTestState
local ____test_2Devents = require("test-events")
local addTestListener = ____test_2Devents.addTestListener
local clearTestListeners = ____test_2Devents.clearTestListeners
function isRunning()
    local stage = getTestState().getTestStage()
    return not (stage == "NotRun" or stage == "LoadError" or stage == "Finished")
end
function loadTests(files, partialConfig)
    local config = fillConfig(partialConfig)
    if config.load_luassert then
        debug.getmetatable = getmetatable
        require("__factorio-test__.luassert.init")
    end
    local defineGlobal = __DebugAdapter and __DebugAdapter.defineGlobal
    if defineGlobal then
        for key in pairs(globals) do
            defineGlobal(nil, key)
        end
    end
    for key, value in pairs(globals) do
        _G[key] = value
    end
    resetTestState(config)
    local state = getTestState()
    local _require = settings.global["factorio-test-mod-to-test"].value == "factorio-test" and require or ____originalRequire
    for ____, file in ipairs(files) do
        describe(
            file,
            function() return _require(file) end
        )
    end
    state.currentBlock = nil
end
function tryContinueTests()
    local testStage = getTestState().getTestStage()
    if testStage == "Running" or testStage == "ReloadingMods" then
        doRunTests()
    else
        revertTappedEvents()
    end
end
function runTests()
    if isRunning() then
        return
    end
    log("Running tests for " .. script.mod_name)
    getTestState().setTestStage("Ready")
    doRunTests()
end
function doRunTests()
    local state = getTestState()
    clearTestListeners()
    __TS__ArrayForEach(builtinTestEventListeners, addTestListener)
    if game ~= nil then
        game.tick_paused = false
    end
    addTestListener(nil, progressGuiListener)
    addMessageHandler(progressGuiLogger)
    if debugAdapterEnabled then
        addMessageHandler(debugAdapterLogger)
    else
        addMessageHandler(logLogger)
    end
    local runner
    tapEvent(
        defines.events.on_tick,
        function()
            if not runner then
                runner = createTestRunner(state)
            end
            runner:tick()
            if runner:isDone() then
                revertTappedEvents()
            end
        end
    )
end
function tapEvent(event, func)
    if not tappedHandlers[event] then
        tappedHandlers[event] = {
            script.get_event_handler(event),
            func
        }
        oldScript.on_event(
            event,
            function(data)
                local handlers = tappedHandlers[event]
                local ____opt_2 = handlers[1]
                if ____opt_2 ~= nil then
                    ____opt_2(data)
                end
                handlers[2]()
            end
        )
    else
        tappedHandlers[event][2] = func
    end
    if rawequal(script, oldScript) then
        local proxyScript = {on_event = function(event, func)
            local handler = tappedHandlers[event]
            if handler then
                handler[1] = func
            else
                oldScript.on_event(event, func)
            end
        end}
        setmetatable(proxyScript, {__index = oldScript, __newindex = oldScript})
        _G.script = proxyScript
    end
end
function revertTappedEvents()
    _G.script = oldScript
    for event, handler in pairs(tappedHandlers) do
        tappedHandlers[event] = nil
        script.on_event(event, handler[1])
    end
end
local function ____exports(files, config)
    loadTests(files, config)
    remote.add_interface(
        "factorio-test",
        {
            runTests = runTests,
            modName = function() return script.mod_name end,
            getTestStage = function() return getTestState().getTestStage() end,
            isRunning = isRunning,
            fireCustomEvent = function(name, data)
                getTestState():raiseTestEvent({type = "customEvent", name = name, data = data})
            end,
            onTestStageChanged = function() return onTestStageChanged end,
            getResults = function() return getTestState().results end
        }
    )
    tapEvent(defines.events.on_tick, tryContinueTests)
end
tappedHandlers = {}
oldScript = script
return ____exports
 end,
}
return require("load", ...)
